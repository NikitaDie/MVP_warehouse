﻿namespace Forms.MenuForms.NewPackage
{
    partial class NewPackageUserDataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            recipentName_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            label7 = new Label();
            recipentPostCode_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel3 = new Panel();
            label8 = new Label();
            recipentLocation_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel4 = new Panel();
            label9 = new Label();
            recipentStreet_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            ReceiverTextboxPanel = new TableLayoutPanel();
            panel7 = new Panel();
            label4 = new Label();
            recipentEmail_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel6 = new Panel();
            label3 = new Label();
            recipentHouseNumber_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            SenderTextboxPanel = new TableLayoutPanel();
            panel8 = new Panel();
            label5 = new Label();
            senderEmail_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel9 = new Panel();
            label6 = new Label();
            senderName_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel10 = new Panel();
            label10 = new Label();
            senderHouseNumber_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel11 = new Panel();
            label11 = new Label();
            senderPostCode_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel12 = new Panel();
            label12 = new Label();
            senderStreet_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            panel13 = new Panel();
            label13 = new Label();
            senderLocation_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            btnNextPage = new Guna.UI2.WinForms.Guna2Button();
            label14 = new Label();
            label15 = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ReceiverTextboxPanel.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            SenderTextboxPanel.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            panel13.SuspendLayout();
            SuspendLayout();
            // 
            // recipentName_textBox
            // 
            recipentName_textBox.Animated = true;
            recipentName_textBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            recipentName_textBox.BorderColor = Color.Black;
            recipentName_textBox.CustomizableEdges = customizableEdges1;
            recipentName_textBox.DefaultText = "";
            recipentName_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentName_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentName_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentName_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentName_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentName_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentName_textBox.ForeColor = Color.Black;
            recipentName_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentName_textBox.Location = new Point(0, 0);
            recipentName_textBox.Margin = new Padding(4);
            recipentName_textBox.Name = "recipentName_textBox";
            recipentName_textBox.PasswordChar = '\0';
            recipentName_textBox.PlaceholderForeColor = Color.DimGray;
            recipentName_textBox.PlaceholderText = "Mark Twain";
            recipentName_textBox.SelectedText = "";
            recipentName_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentName_textBox.ShadowDecoration.CustomizableEdges = customizableEdges2;
            recipentName_textBox.Size = new Size(442, 44);
            recipentName_textBox.TabIndex = 0;
            recipentName_textBox.TextOffset = new Point(0, 5);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(125, 137, 149);
            label1.Location = new Point(5, 3);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new Size(135, 13);
            label1.TabIndex = 10;
            label1.Text = "FIRST- AND LASTNAME*";
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(recipentName_textBox);
            panel1.Location = new Point(7, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(442, 44);
            panel1.TabIndex = 21;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.Controls.Add(label7);
            panel2.Controls.Add(recipentPostCode_textBox);
            panel2.Location = new Point(7, 59);
            panel2.Name = "panel2";
            panel2.Size = new Size(442, 44);
            panel2.TabIndex = 22;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.White;
            label7.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(125, 137, 149);
            label7.Location = new Point(5, 3);
            label7.Margin = new Padding(0);
            label7.Name = "label7";
            label7.Size = new Size(71, 13);
            label7.TabIndex = 10;
            label7.Text = "POST CODE*";
            // 
            // recipentPostCode_textBox
            // 
            recipentPostCode_textBox.Animated = true;
            recipentPostCode_textBox.BorderColor = Color.Black;
            recipentPostCode_textBox.CustomizableEdges = customizableEdges3;
            recipentPostCode_textBox.DefaultText = "";
            recipentPostCode_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentPostCode_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentPostCode_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentPostCode_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentPostCode_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentPostCode_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentPostCode_textBox.ForeColor = Color.Black;
            recipentPostCode_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentPostCode_textBox.Location = new Point(0, 0);
            recipentPostCode_textBox.Margin = new Padding(4);
            recipentPostCode_textBox.Name = "recipentPostCode_textBox";
            recipentPostCode_textBox.PasswordChar = '\0';
            recipentPostCode_textBox.PlaceholderForeColor = Color.DimGray;
            recipentPostCode_textBox.PlaceholderText = "52525";
            recipentPostCode_textBox.SelectedText = "";
            recipentPostCode_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentPostCode_textBox.ShadowDecoration.CustomizableEdges = customizableEdges4;
            recipentPostCode_textBox.Size = new Size(442, 44);
            recipentPostCode_textBox.TabIndex = 0;
            recipentPostCode_textBox.TextOffset = new Point(0, 5);
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.Controls.Add(label8);
            panel3.Controls.Add(recipentLocation_textBox);
            panel3.Location = new Point(7, 113);
            panel3.Name = "panel3";
            panel3.Size = new Size(442, 44);
            panel3.TabIndex = 23;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(125, 137, 149);
            label8.Location = new Point(5, 3);
            label8.Margin = new Padding(0);
            label8.Name = "label8";
            label8.Size = new Size(74, 13);
            label8.TabIndex = 10;
            label8.Text = "CITY/TOWN*";
            // 
            // recipentLocation_textBox
            // 
            recipentLocation_textBox.Animated = true;
            recipentLocation_textBox.BorderColor = Color.Black;
            recipentLocation_textBox.CustomizableEdges = customizableEdges5;
            recipentLocation_textBox.DefaultText = "";
            recipentLocation_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentLocation_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentLocation_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentLocation_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentLocation_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentLocation_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentLocation_textBox.ForeColor = Color.Black;
            recipentLocation_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentLocation_textBox.Location = new Point(0, 0);
            recipentLocation_textBox.Margin = new Padding(4);
            recipentLocation_textBox.Name = "recipentLocation_textBox";
            recipentLocation_textBox.PasswordChar = '\0';
            recipentLocation_textBox.PlaceholderForeColor = Color.DimGray;
            recipentLocation_textBox.PlaceholderText = "Hartford";
            recipentLocation_textBox.SelectedText = "";
            recipentLocation_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentLocation_textBox.ShadowDecoration.CustomizableEdges = customizableEdges6;
            recipentLocation_textBox.Size = new Size(442, 44);
            recipentLocation_textBox.TabIndex = 0;
            recipentLocation_textBox.TextOffset = new Point(0, 5);
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.Controls.Add(label9);
            panel4.Controls.Add(recipentStreet_textBox);
            panel4.Location = new Point(7, 167);
            panel4.Name = "panel4";
            panel4.Size = new Size(442, 44);
            panel4.TabIndex = 24;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(125, 137, 149);
            label9.Location = new Point(5, 3);
            label9.Margin = new Padding(0);
            label9.Name = "label9";
            label9.Size = new Size(49, 13);
            label9.TabIndex = 10;
            label9.Text = "STREET*";
            // 
            // recipentStreet_textBox
            // 
            recipentStreet_textBox.Animated = true;
            recipentStreet_textBox.BorderColor = Color.Black;
            recipentStreet_textBox.CustomizableEdges = customizableEdges7;
            recipentStreet_textBox.DefaultText = "";
            recipentStreet_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentStreet_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentStreet_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentStreet_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentStreet_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentStreet_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentStreet_textBox.ForeColor = Color.Black;
            recipentStreet_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentStreet_textBox.Location = new Point(0, 0);
            recipentStreet_textBox.Margin = new Padding(4);
            recipentStreet_textBox.Name = "recipentStreet_textBox";
            recipentStreet_textBox.PasswordChar = '\0';
            recipentStreet_textBox.PlaceholderForeColor = Color.DimGray;
            recipentStreet_textBox.PlaceholderText = "Farmington Ave";
            recipentStreet_textBox.SelectedText = "";
            recipentStreet_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentStreet_textBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            recipentStreet_textBox.Size = new Size(442, 44);
            recipentStreet_textBox.TabIndex = 0;
            recipentStreet_textBox.TextOffset = new Point(0, 5);
            // 
            // ReceiverTextboxPanel
            // 
            ReceiverTextboxPanel.ColumnCount = 1;
            ReceiverTextboxPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            ReceiverTextboxPanel.Controls.Add(panel7, 0, 5);
            ReceiverTextboxPanel.Controls.Add(panel1, 0, 0);
            ReceiverTextboxPanel.Controls.Add(panel6, 0, 4);
            ReceiverTextboxPanel.Controls.Add(panel2, 0, 1);
            ReceiverTextboxPanel.Controls.Add(panel4, 0, 3);
            ReceiverTextboxPanel.Controls.Add(panel3, 0, 2);
            ReceiverTextboxPanel.Location = new Point(12, 48);
            ReceiverTextboxPanel.Name = "ReceiverTextboxPanel";
            ReceiverTextboxPanel.RowCount = 6;
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            ReceiverTextboxPanel.Size = new Size(457, 327);
            ReceiverTextboxPanel.TabIndex = 26;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.Controls.Add(label4);
            panel7.Controls.Add(recipentEmail_textBox);
            panel7.Location = new Point(7, 276);
            panel7.Name = "panel7";
            panel7.Size = new Size(442, 44);
            panel7.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(125, 137, 149);
            label4.Location = new Point(5, 3);
            label4.Margin = new Padding(0);
            label4.Name = "label4";
            label4.Size = new Size(147, 13);
            label4.TabIndex = 10;
            label4.Text = "E-MAIL OF THE RECIPIENT*";
            // 
            // recipentEmail_textBox
            // 
            recipentEmail_textBox.Animated = true;
            recipentEmail_textBox.BorderColor = Color.Black;
            recipentEmail_textBox.CustomizableEdges = customizableEdges9;
            recipentEmail_textBox.DefaultText = "";
            recipentEmail_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentEmail_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentEmail_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentEmail_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentEmail_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentEmail_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentEmail_textBox.ForeColor = Color.Black;
            recipentEmail_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentEmail_textBox.Location = new Point(0, 0);
            recipentEmail_textBox.Margin = new Padding(4);
            recipentEmail_textBox.Name = "recipentEmail_textBox";
            recipentEmail_textBox.PasswordChar = '\0';
            recipentEmail_textBox.PlaceholderForeColor = Color.DimGray;
            recipentEmail_textBox.PlaceholderText = "mark.twain@gmail.com";
            recipentEmail_textBox.SelectedText = "";
            recipentEmail_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentEmail_textBox.ShadowDecoration.CustomizableEdges = customizableEdges10;
            recipentEmail_textBox.Size = new Size(442, 44);
            recipentEmail_textBox.TabIndex = 0;
            recipentEmail_textBox.TextOffset = new Point(0, 5);
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.Controls.Add(label3);
            panel6.Controls.Add(recipentHouseNumber_textBox);
            panel6.Location = new Point(7, 221);
            panel6.Name = "panel6";
            panel6.Size = new Size(442, 44);
            panel6.TabIndex = 27;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(125, 137, 149);
            label3.Location = new Point(5, 3);
            label3.Margin = new Padding(0);
            label3.Name = "label3";
            label3.Size = new Size(99, 13);
            label3.TabIndex = 10;
            label3.Text = "HOUSE NUMBER*";
            // 
            // recipentHouseNumber_textBox
            // 
            recipentHouseNumber_textBox.Animated = true;
            recipentHouseNumber_textBox.BorderColor = Color.Black;
            recipentHouseNumber_textBox.CustomizableEdges = customizableEdges11;
            recipentHouseNumber_textBox.DefaultText = "";
            recipentHouseNumber_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            recipentHouseNumber_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            recipentHouseNumber_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            recipentHouseNumber_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            recipentHouseNumber_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentHouseNumber_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            recipentHouseNumber_textBox.ForeColor = Color.Black;
            recipentHouseNumber_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            recipentHouseNumber_textBox.Location = new Point(0, 0);
            recipentHouseNumber_textBox.Margin = new Padding(4);
            recipentHouseNumber_textBox.Name = "recipentHouseNumber_textBox";
            recipentHouseNumber_textBox.PasswordChar = '\0';
            recipentHouseNumber_textBox.PlaceholderForeColor = Color.DimGray;
            recipentHouseNumber_textBox.PlaceholderText = "351";
            recipentHouseNumber_textBox.SelectedText = "";
            recipentHouseNumber_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            recipentHouseNumber_textBox.ShadowDecoration.CustomizableEdges = customizableEdges12;
            recipentHouseNumber_textBox.Size = new Size(442, 44);
            recipentHouseNumber_textBox.TabIndex = 0;
            recipentHouseNumber_textBox.TextOffset = new Point(0, 5);
            // 
            // SenderTextboxPanel
            // 
            SenderTextboxPanel.ColumnCount = 1;
            SenderTextboxPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            SenderTextboxPanel.Controls.Add(panel8, 0, 5);
            SenderTextboxPanel.Controls.Add(panel9, 0, 0);
            SenderTextboxPanel.Controls.Add(panel10, 0, 4);
            SenderTextboxPanel.Controls.Add(panel11, 0, 1);
            SenderTextboxPanel.Controls.Add(panel12, 0, 3);
            SenderTextboxPanel.Controls.Add(panel13, 0, 2);
            SenderTextboxPanel.Location = new Point(531, 48);
            SenderTextboxPanel.Name = "SenderTextboxPanel";
            SenderTextboxPanel.RowCount = 6;
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            SenderTextboxPanel.Size = new Size(457, 327);
            SenderTextboxPanel.TabIndex = 27;
            // 
            // panel8
            // 
            panel8.Anchor = AnchorStyles.None;
            panel8.Controls.Add(label5);
            panel8.Controls.Add(senderEmail_textBox);
            panel8.Location = new Point(7, 276);
            panel8.Name = "panel8";
            panel8.Size = new Size(442, 44);
            panel8.TabIndex = 28;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(125, 137, 149);
            label5.Location = new Point(5, 3);
            label5.Margin = new Padding(0);
            label5.Name = "label5";
            label5.Size = new Size(135, 13);
            label5.TabIndex = 10;
            label5.Text = "E-MAIL OF THE SENDER*";
            // 
            // senderEmail_textBox
            // 
            senderEmail_textBox.Animated = true;
            senderEmail_textBox.BorderColor = Color.Black;
            senderEmail_textBox.CustomizableEdges = customizableEdges13;
            senderEmail_textBox.DefaultText = "";
            senderEmail_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderEmail_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderEmail_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderEmail_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderEmail_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderEmail_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderEmail_textBox.ForeColor = Color.Black;
            senderEmail_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderEmail_textBox.Location = new Point(0, 0);
            senderEmail_textBox.Margin = new Padding(4);
            senderEmail_textBox.Name = "senderEmail_textBox";
            senderEmail_textBox.PasswordChar = '\0';
            senderEmail_textBox.PlaceholderForeColor = Color.DimGray;
            senderEmail_textBox.PlaceholderText = "harry.potter@gmail.com";
            senderEmail_textBox.SelectedText = "";
            senderEmail_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderEmail_textBox.ShadowDecoration.CustomizableEdges = customizableEdges14;
            senderEmail_textBox.Size = new Size(442, 44);
            senderEmail_textBox.TabIndex = 0;
            senderEmail_textBox.TextOffset = new Point(0, 5);
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.Controls.Add(label6);
            panel9.Controls.Add(senderName_textBox);
            panel9.Location = new Point(7, 5);
            panel9.Name = "panel9";
            panel9.Size = new Size(442, 44);
            panel9.TabIndex = 21;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(125, 137, 149);
            label6.Location = new Point(5, 3);
            label6.Margin = new Padding(0);
            label6.Name = "label6";
            label6.Size = new Size(135, 13);
            label6.TabIndex = 10;
            label6.Text = "FIRST- AND LASTNAME*";
            // 
            // senderName_textBox
            // 
            senderName_textBox.Animated = true;
            senderName_textBox.BorderColor = Color.Black;
            senderName_textBox.CustomizableEdges = customizableEdges15;
            senderName_textBox.DefaultText = "";
            senderName_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderName_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderName_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderName_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderName_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderName_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderName_textBox.ForeColor = Color.Black;
            senderName_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderName_textBox.Location = new Point(0, 0);
            senderName_textBox.Margin = new Padding(4);
            senderName_textBox.Name = "senderName_textBox";
            senderName_textBox.PasswordChar = '\0';
            senderName_textBox.PlaceholderForeColor = Color.DimGray;
            senderName_textBox.PlaceholderText = "Harry Potter";
            senderName_textBox.SelectedText = "";
            senderName_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderName_textBox.ShadowDecoration.CustomizableEdges = customizableEdges16;
            senderName_textBox.Size = new Size(442, 44);
            senderName_textBox.TabIndex = 0;
            senderName_textBox.TextOffset = new Point(0, 5);
            // 
            // panel10
            // 
            panel10.Anchor = AnchorStyles.None;
            panel10.Controls.Add(label10);
            panel10.Controls.Add(senderHouseNumber_textBox);
            panel10.Location = new Point(7, 221);
            panel10.Name = "panel10";
            panel10.Size = new Size(442, 44);
            panel10.TabIndex = 27;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(125, 137, 149);
            label10.Location = new Point(5, 3);
            label10.Margin = new Padding(0);
            label10.Name = "label10";
            label10.Size = new Size(99, 13);
            label10.TabIndex = 10;
            label10.Text = "HOUSE NUMBER*";
            // 
            // senderHouseNumber_textBox
            // 
            senderHouseNumber_textBox.Animated = true;
            senderHouseNumber_textBox.BorderColor = Color.Black;
            senderHouseNumber_textBox.CustomizableEdges = customizableEdges17;
            senderHouseNumber_textBox.DefaultText = "";
            senderHouseNumber_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderHouseNumber_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderHouseNumber_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderHouseNumber_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderHouseNumber_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderHouseNumber_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderHouseNumber_textBox.ForeColor = Color.Black;
            senderHouseNumber_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderHouseNumber_textBox.Location = new Point(0, 0);
            senderHouseNumber_textBox.Margin = new Padding(4);
            senderHouseNumber_textBox.Name = "senderHouseNumber_textBox";
            senderHouseNumber_textBox.PasswordChar = '\0';
            senderHouseNumber_textBox.PlaceholderForeColor = Color.DimGray;
            senderHouseNumber_textBox.PlaceholderText = "4";
            senderHouseNumber_textBox.SelectedText = "";
            senderHouseNumber_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderHouseNumber_textBox.ShadowDecoration.CustomizableEdges = customizableEdges18;
            senderHouseNumber_textBox.Size = new Size(442, 44);
            senderHouseNumber_textBox.TabIndex = 0;
            senderHouseNumber_textBox.TextOffset = new Point(0, 5);
            // 
            // panel11
            // 
            panel11.Anchor = AnchorStyles.None;
            panel11.Controls.Add(label11);
            panel11.Controls.Add(senderPostCode_textBox);
            panel11.Location = new Point(7, 59);
            panel11.Name = "panel11";
            panel11.Size = new Size(442, 44);
            panel11.TabIndex = 22;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(125, 137, 149);
            label11.Location = new Point(5, 3);
            label11.Margin = new Padding(0);
            label11.Name = "label11";
            label11.Size = new Size(71, 13);
            label11.TabIndex = 10;
            label11.Text = "POST CODE*";
            // 
            // senderPostCode_textBox
            // 
            senderPostCode_textBox.Animated = true;
            senderPostCode_textBox.BorderColor = Color.Black;
            senderPostCode_textBox.CustomizableEdges = customizableEdges19;
            senderPostCode_textBox.DefaultText = "";
            senderPostCode_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderPostCode_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderPostCode_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderPostCode_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderPostCode_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderPostCode_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderPostCode_textBox.ForeColor = Color.Black;
            senderPostCode_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderPostCode_textBox.Location = new Point(0, 0);
            senderPostCode_textBox.Margin = new Padding(4);
            senderPostCode_textBox.Name = "senderPostCode_textBox";
            senderPostCode_textBox.PasswordChar = '\0';
            senderPostCode_textBox.PlaceholderForeColor = Color.DimGray;
            senderPostCode_textBox.PlaceholderText = "RG12";
            senderPostCode_textBox.SelectedText = "";
            senderPostCode_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderPostCode_textBox.ShadowDecoration.CustomizableEdges = customizableEdges20;
            senderPostCode_textBox.Size = new Size(442, 44);
            senderPostCode_textBox.TabIndex = 0;
            senderPostCode_textBox.TextOffset = new Point(0, 5);
            // 
            // panel12
            // 
            panel12.Anchor = AnchorStyles.None;
            panel12.Controls.Add(label12);
            panel12.Controls.Add(senderStreet_textBox);
            panel12.Location = new Point(7, 167);
            panel12.Name = "panel12";
            panel12.Size = new Size(442, 44);
            panel12.TabIndex = 24;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.White;
            label12.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(125, 137, 149);
            label12.Location = new Point(5, 3);
            label12.Margin = new Padding(0);
            label12.Name = "label12";
            label12.Size = new Size(49, 13);
            label12.TabIndex = 10;
            label12.Text = "STREET*";
            // 
            // senderStreet_textBox
            // 
            senderStreet_textBox.Animated = true;
            senderStreet_textBox.BorderColor = Color.Black;
            senderStreet_textBox.CustomizableEdges = customizableEdges21;
            senderStreet_textBox.DefaultText = "";
            senderStreet_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderStreet_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderStreet_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderStreet_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderStreet_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderStreet_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderStreet_textBox.ForeColor = Color.Black;
            senderStreet_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderStreet_textBox.Location = new Point(0, 0);
            senderStreet_textBox.Margin = new Padding(4);
            senderStreet_textBox.Name = "senderStreet_textBox";
            senderStreet_textBox.PasswordChar = '\0';
            senderStreet_textBox.PlaceholderForeColor = Color.DimGray;
            senderStreet_textBox.PlaceholderText = "Privet Drive";
            senderStreet_textBox.SelectedText = "";
            senderStreet_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderStreet_textBox.ShadowDecoration.CustomizableEdges = customizableEdges22;
            senderStreet_textBox.Size = new Size(442, 44);
            senderStreet_textBox.TabIndex = 0;
            senderStreet_textBox.TextOffset = new Point(0, 5);
            // 
            // panel13
            // 
            panel13.Anchor = AnchorStyles.None;
            panel13.Controls.Add(label13);
            panel13.Controls.Add(senderLocation_textBox);
            panel13.Location = new Point(7, 113);
            panel13.Name = "panel13";
            panel13.Size = new Size(442, 44);
            panel13.TabIndex = 23;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.White;
            label13.Font = new Font("Leelawadee UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(125, 137, 149);
            label13.Location = new Point(5, 3);
            label13.Margin = new Padding(0);
            label13.Name = "label13";
            label13.Size = new Size(74, 13);
            label13.TabIndex = 10;
            label13.Text = "CITY/TOWN*";
            // 
            // senderLocation_textBox
            // 
            senderLocation_textBox.Animated = true;
            senderLocation_textBox.BorderColor = Color.Black;
            senderLocation_textBox.CustomizableEdges = customizableEdges23;
            senderLocation_textBox.DefaultText = "";
            senderLocation_textBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            senderLocation_textBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            senderLocation_textBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            senderLocation_textBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            senderLocation_textBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            senderLocation_textBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            senderLocation_textBox.ForeColor = Color.Black;
            senderLocation_textBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            senderLocation_textBox.Location = new Point(0, 0);
            senderLocation_textBox.Margin = new Padding(4);
            senderLocation_textBox.Name = "senderLocation_textBox";
            senderLocation_textBox.PasswordChar = '\0';
            senderLocation_textBox.PlaceholderForeColor = Color.DimGray;
            senderLocation_textBox.PlaceholderText = "Little Whinging";
            senderLocation_textBox.SelectedText = "";
            senderLocation_textBox.ShadowDecoration.Color = Color.FromArgb(94, 148, 255);
            senderLocation_textBox.ShadowDecoration.CustomizableEdges = customizableEdges24;
            senderLocation_textBox.Size = new Size(442, 44);
            senderLocation_textBox.TabIndex = 0;
            senderLocation_textBox.TextOffset = new Point(0, 5);
            // 
            // guna2CircleButton1
            // 
            guna2CircleButton1.CheckedState.FillColor = Color.Lime;
            guna2CircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton1.FillColor = Color.FromArgb(212, 5, 17);
            guna2CircleButton1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton1.ForeColor = Color.White;
            guna2CircleButton1.Image = Properties.Resources.plus;
            guna2CircleButton1.ImageSize = new Size(16, 16);
            guna2CircleButton1.Location = new Point(19, 454);
            guna2CircleButton1.Name = "guna2CircleButton1";
            guna2CircleButton1.PressedColor = Color.Transparent;
            guna2CircleButton1.PressedDepth = 0;
            guna2CircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges25;
            guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton1.Size = new Size(24, 24);
            guna2CircleButton1.TabIndex = 29;
            // 
            // btnNextPage
            // 
            btnNextPage.Animated = true;
            btnNextPage.BorderColor = Color.Transparent;
            btnNextPage.BorderRadius = 3;
            btnNextPage.BorderThickness = 2;
            btnNextPage.CheckedState.BorderColor = Color.FromArgb(212, 5, 17);
            btnNextPage.CheckedState.FillColor = SystemColors.Control;
            btnNextPage.CheckedState.ForeColor = Color.FromArgb(212, 5, 17);
            btnNextPage.CustomizableEdges = customizableEdges26;
            btnNextPage.DisabledState.BorderColor = Color.DarkGray;
            btnNextPage.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNextPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNextPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNextPage.FillColor = Color.FromArgb(212, 5, 17);
            btnNextPage.Font = new Font("Calibri", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnNextPage.ForeColor = Color.White;
            btnNextPage.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            btnNextPage.HoverState.FillColor = Color.Transparent;
            btnNextPage.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            btnNextPage.Location = new Point(19, 542);
            btnNextPage.Name = "btnNextPage";
            btnNextPage.ShadowDecoration.CustomizableEdges = customizableEdges27;
            btnNextPage.Size = new Size(345, 39);
            btnNextPage.TabIndex = 28;
            btnNextPage.Text = "Continue to payment";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(10, 10, 10);
            label14.Location = new Point(531, 18);
            label14.Name = "label14";
            label14.Size = new Size(93, 32);
            label14.TabIndex = 30;
            label14.Text = "Sender";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(10, 10, 10);
            label15.Location = new Point(12, 18);
            label15.Name = "label15";
            label15.Size = new Size(111, 32);
            label15.TabIndex = 31;
            label15.Text = "Receiver";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(10, 10, 10);
            label2.Location = new Point(12, 409);
            label2.Name = "label2";
            label2.Size = new Size(323, 32);
            label2.TabIndex = 32;
            label2.Text = "Complete shipping options";
            // 
            // NewPackageUserDataForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(1000, 600);
            Controls.Add(label2);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(guna2CircleButton1);
            Controls.Add(btnNextPage);
            Controls.Add(SenderTextboxPanel);
            Controls.Add(ReceiverTextboxPanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewPackageUserDataForm";
            Text = "NewPackageUserDataForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ReceiverTextboxPanel.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            SenderTextboxPanel.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox recipentName_textBox;
        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox recipentPostCode_textBox;
        private Panel panel3;
        private Label label8;
        private Guna.UI2.WinForms.Guna2TextBox recipentLocation_textBox;
        private Panel panel4;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox recipentStreet_textBox;
        private TableLayoutPanel ReceiverTextboxPanel;
        private Panel panel7;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox recipentEmail_textBox;
        private Panel panel6;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox recipentHouseNumber_textBox;
        private TableLayoutPanel SenderTextboxPanel;
        private Panel panel8;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox senderEmail_textBox;
        private Panel panel9;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox senderName_textBox;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2Button btnNextPage;
        private Panel panel10;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox senderHouseNumber_textBox;
        private Panel panel11;
        private Label label11;
        private Guna.UI2.WinForms.Guna2TextBox senderPostCode_textBox;
        private Panel panel12;
        private Label label12;
        private Guna.UI2.WinForms.Guna2TextBox senderStreet_textBox;
        private Panel panel13;
        private Label label13;
        private Guna.UI2.WinForms.Guna2TextBox senderLocation_textBox;
        private Label label14;
        private Label label15;
        private Label label2;
    }
}