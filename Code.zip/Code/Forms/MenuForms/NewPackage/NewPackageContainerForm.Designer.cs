﻿namespace Forms.MenuForms.NewPackage
{
    partial class NewPackageContainerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel_Loader = new Panel();
            guna2vProgressBar1 = new Guna.UI2.WinForms.Guna2VProgressBar();
            guna2CircleProgressBar1 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            guna2CircleProgressBar5 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            guna2CircleProgressBar3 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            ProgressBar_tableLayoutPanel = new TableLayoutPanel();
            guna2vProgressBar5 = new Guna.UI2.WinForms.Guna2VProgressBar();
            guna2vProgressBar4 = new Guna.UI2.WinForms.Guna2VProgressBar();
            ProgressBar_tableLayoutPanel.SuspendLayout();
            SuspendLayout();
            // 
            // panel_Loader
            // 
            panel_Loader.Dock = DockStyle.Bottom;
            panel_Loader.Location = new Point(0, 100);
            panel_Loader.Name = "panel_Loader";
            panel_Loader.Size = new Size(1000, 600);
            panel_Loader.TabIndex = 0;
            // 
            // guna2vProgressBar1
            // 
            guna2vProgressBar1.Anchor = AnchorStyles.None;
            guna2vProgressBar1.CustomizableEdges = customizableEdges1;
            guna2vProgressBar1.FillColor = Color.FromArgb(200, 213, 218, 223);
            guna2vProgressBar1.Location = new Point(63, 31);
            guna2vProgressBar1.Margin = new Padding(0);
            guna2vProgressBar1.Name = "guna2vProgressBar1";
            guna2vProgressBar1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2vProgressBar1.Size = new Size(241, 3);
            guna2vProgressBar1.TabIndex = 1;
            guna2vProgressBar1.Text = "guna2vProgressBar1";
            guna2vProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // guna2CircleProgressBar1
            // 
            guna2CircleProgressBar1.Anchor = AnchorStyles.Right;
            guna2CircleProgressBar1.FillColor = Color.FromArgb(200, 213, 218, 223);
            guna2CircleProgressBar1.FillThickness = 0;
            guna2CircleProgressBar1.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            guna2CircleProgressBar1.ForeColor = Color.FromArgb(102, 102, 102);
            guna2CircleProgressBar1.Location = new Point(4, 4);
            guna2CircleProgressBar1.Minimum = 0;
            guna2CircleProgressBar1.Name = "guna2CircleProgressBar1";
            guna2CircleProgressBar1.ProgressColor = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar1.ProgressColor2 = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar1.ProgressThickness = 3;
            guna2CircleProgressBar1.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleProgressBar1.ShowText = true;
            guna2CircleProgressBar1.Size = new Size(56, 56);
            guna2CircleProgressBar1.TabIndex = 2;
            guna2CircleProgressBar1.Text = "1";
            guna2CircleProgressBar1.TextMode = Guna.UI2.WinForms.Enums.ProgressBarTextMode.Custom;
            guna2CircleProgressBar1.Value = 100;
            // 
            // guna2CircleProgressBar5
            // 
            guna2CircleProgressBar5.Anchor = AnchorStyles.Right;
            guna2CircleProgressBar5.FillColor = Color.FromArgb(200, 213, 218, 223);
            guna2CircleProgressBar5.FillThickness = 0;
            guna2CircleProgressBar5.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            guna2CircleProgressBar5.ForeColor = Color.FromArgb(102, 102, 102);
            guna2CircleProgressBar5.Location = new Point(308, 4);
            guna2CircleProgressBar5.Minimum = 0;
            guna2CircleProgressBar5.Name = "guna2CircleProgressBar5";
            guna2CircleProgressBar5.ProgressColor = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar5.ProgressColor2 = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar5.ProgressThickness = 3;
            guna2CircleProgressBar5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2CircleProgressBar5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleProgressBar5.ShowText = true;
            guna2CircleProgressBar5.Size = new Size(56, 56);
            guna2CircleProgressBar5.TabIndex = 3;
            guna2CircleProgressBar5.Text = "2";
            guna2CircleProgressBar5.TextMode = Guna.UI2.WinForms.Enums.ProgressBarTextMode.Custom;
            guna2CircleProgressBar5.Value = 100;
            // 
            // guna2CircleProgressBar2
            // 
            guna2CircleProgressBar2.Anchor = AnchorStyles.Right;
            guna2CircleProgressBar2.FillColor = Color.FromArgb(200, 213, 218, 223);
            guna2CircleProgressBar2.FillThickness = 0;
            guna2CircleProgressBar2.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            guna2CircleProgressBar2.ForeColor = Color.FromArgb(102, 102, 102);
            guna2CircleProgressBar2.Location = new Point(612, 4);
            guna2CircleProgressBar2.Minimum = 0;
            guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            guna2CircleProgressBar2.ProgressColor = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar2.ProgressColor2 = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar2.ProgressThickness = 3;
            guna2CircleProgressBar2.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleProgressBar2.ShowText = true;
            guna2CircleProgressBar2.Size = new Size(56, 56);
            guna2CircleProgressBar2.TabIndex = 3;
            guna2CircleProgressBar2.Text = "3";
            guna2CircleProgressBar2.TextMode = Guna.UI2.WinForms.Enums.ProgressBarTextMode.Custom;
            guna2CircleProgressBar2.Value = 100;
            // 
            // guna2CircleProgressBar3
            // 
            guna2CircleProgressBar3.Anchor = AnchorStyles.None;
            guna2CircleProgressBar3.FillColor = Color.FromArgb(200, 213, 218, 223);
            guna2CircleProgressBar3.FillThickness = 0;
            guna2CircleProgressBar3.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            guna2CircleProgressBar3.ForeColor = Color.FromArgb(102, 102, 102);
            guna2CircleProgressBar3.Location = new Point(916, 4);
            guna2CircleProgressBar3.Minimum = 0;
            guna2CircleProgressBar3.Name = "guna2CircleProgressBar3";
            guna2CircleProgressBar3.ProgressColor = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar3.ProgressColor2 = Color.FromArgb(72, 180, 81);
            guna2CircleProgressBar3.ProgressThickness = 3;
            guna2CircleProgressBar3.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleProgressBar3.ShowText = true;
            guna2CircleProgressBar3.Size = new Size(56, 56);
            guna2CircleProgressBar3.TabIndex = 3;
            guna2CircleProgressBar3.Text = "4";
            guna2CircleProgressBar3.TextMode = Guna.UI2.WinForms.Enums.ProgressBarTextMode.Custom;
            guna2CircleProgressBar3.Value = 100;
            // 
            // ProgressBar_tableLayoutPanel
            // 
            ProgressBar_tableLayoutPanel.ColumnCount = 7;
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 63F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 63F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 63F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            ProgressBar_tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 63F));
            ProgressBar_tableLayoutPanel.Controls.Add(guna2CircleProgressBar3, 6, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2CircleProgressBar1, 0, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2vProgressBar5, 5, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2vProgressBar1, 1, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2CircleProgressBar2, 4, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2vProgressBar4, 3, 0);
            ProgressBar_tableLayoutPanel.Controls.Add(guna2CircleProgressBar5, 2, 0);
            ProgressBar_tableLayoutPanel.Location = new Point(12, 18);
            ProgressBar_tableLayoutPanel.Name = "ProgressBar_tableLayoutPanel";
            ProgressBar_tableLayoutPanel.RowCount = 1;
            ProgressBar_tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            ProgressBar_tableLayoutPanel.Size = new Size(976, 65);
            ProgressBar_tableLayoutPanel.TabIndex = 6;
            // 
            // guna2vProgressBar5
            // 
            guna2vProgressBar5.Anchor = AnchorStyles.None;
            guna2vProgressBar5.CustomizableEdges = customizableEdges7;
            guna2vProgressBar5.FillColor = Color.FromArgb(224, 224, 224);
            guna2vProgressBar5.Location = new Point(671, 31);
            guna2vProgressBar5.Margin = new Padding(0);
            guna2vProgressBar5.Name = "guna2vProgressBar5";
            guna2vProgressBar5.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2vProgressBar5.Size = new Size(241, 3);
            guna2vProgressBar5.TabIndex = 5;
            guna2vProgressBar5.Text = "guna2vProgressBar5";
            guna2vProgressBar5.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // guna2vProgressBar4
            // 
            guna2vProgressBar4.Anchor = AnchorStyles.None;
            guna2vProgressBar4.CustomizableEdges = customizableEdges9;
            guna2vProgressBar4.FillColor = Color.FromArgb(224, 224, 224);
            guna2vProgressBar4.Location = new Point(367, 31);
            guna2vProgressBar4.Margin = new Padding(0);
            guna2vProgressBar4.Name = "guna2vProgressBar4";
            guna2vProgressBar4.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2vProgressBar4.Size = new Size(241, 3);
            guna2vProgressBar4.TabIndex = 4;
            guna2vProgressBar4.Text = "guna2vProgressBar4";
            guna2vProgressBar4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // NewPackageContainerForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(1000, 700);
            Controls.Add(ProgressBar_tableLayoutPanel);
            Controls.Add(panel_Loader);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewPackageContainerForm";
            Text = "NewPackageContainerForm";
            ProgressBar_tableLayoutPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel_Loader;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2vProgressBar1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar5;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar3;
        private TableLayoutPanel ProgressBar_tableLayoutPanel;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2vProgressBar5;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2vProgressBar4;
    }
}