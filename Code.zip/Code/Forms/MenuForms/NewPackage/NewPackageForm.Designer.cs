﻿namespace Forms.MenuForms.NewPackage
{
    partial class NewPackageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges54 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges63 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges64 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges57 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges58 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges55 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges56 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges59 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges60 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges61 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges62 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            OptionPanelBase1 = new Controls.OptionPanel();
            OptionPanelMask1 = new Controls.OptionPanel();
            OptionPanelButton1 = new Controls.HoverButton();
            OptinPanelWhitePanel1 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking1 = new Label();
            OptionPanelLiability1 = new Label();
            OptionPanelSizeDescription1 = new Label();
            OptionPanelName1 = new Label();
            OptionPanelHeader1 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelPrice1 = new Label();
            OptionPanelBase2 = new Controls.OptionPanel();
            OptionPanelMask2 = new Controls.OptionPanel();
            hoverButton1 = new Controls.HoverButton();
            white2 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking2 = new Label();
            OptionPanelLiability2 = new Label();
            OptionPanelSizeDescription2 = new Label();
            OptionPanelName2 = new Label();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelPrice2 = new Label();
            OptionPanelBase3 = new Controls.OptionPanel();
            OptionPanelMask3 = new Controls.OptionPanel();
            OptionPanelButton3 = new Controls.HoverButton();
            white3 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking3 = new Label();
            OptionPanelLiability3 = new Label();
            OptionPanelSizeDescription3 = new Label();
            OptionPanelName3 = new Label();
            guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            label10OptionPanelPrice3 = new Label();
            OptionPanelBase5 = new Controls.OptionPanel();
            OptionPanelMask5 = new Controls.OptionPanel();
            OptionPanelButton5 = new Controls.HoverButton();
            white5 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking5 = new Label();
            OptionPanelLiability5 = new Label();
            OptionPanelSizeDescription5 = new Label();
            OptionPanelName5 = new Label();
            guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelPrice5 = new Label();
            OptionPanelBase4 = new Controls.OptionPanel();
            OptionPanelMask4 = new Controls.OptionPanel();
            OptionPanelButton4 = new Controls.HoverButton();
            white4 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking4 = new Label();
            OptionPanelLiability4 = new Label();
            OptionPanelSizeDescription4 = new Label();
            OptionPanelName4 = new Label();
            guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelPrice4 = new Label();
            btnNextPage = new Guna.UI2.WinForms.Guna2Button();
            OptionPanelBase6 = new Controls.OptionPanel();
            OptionPanelMask6 = new Controls.OptionPanel();
            OptionPanelButton6 = new Controls.HoverButton();
            white6 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelTraking6 = new Label();
            OptionPanelLiability6 = new Label();
            OptionPanelSizeDescription6 = new Label();
            OptionPanelName6 = new Label();
            guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            OptionPanelPrice6 = new Label();
            panel_login = new Panel();
            label1 = new Label();
            MainPanel = new Panel();
            OptionPanelBase1.SuspendLayout();
            OptionPanelMask1.SuspendLayout();
            OptinPanelWhitePanel1.SuspendLayout();
            OptionPanelHeader1.SuspendLayout();
            OptionPanelBase2.SuspendLayout();
            OptionPanelMask2.SuspendLayout();
            white2.SuspendLayout();
            guna2Panel2.SuspendLayout();
            OptionPanelBase3.SuspendLayout();
            OptionPanelMask3.SuspendLayout();
            white3.SuspendLayout();
            guna2Panel4.SuspendLayout();
            OptionPanelBase5.SuspendLayout();
            OptionPanelMask5.SuspendLayout();
            white5.SuspendLayout();
            guna2Panel6.SuspendLayout();
            OptionPanelBase4.SuspendLayout();
            OptionPanelMask4.SuspendLayout();
            white4.SuspendLayout();
            guna2Panel8.SuspendLayout();
            OptionPanelBase6.SuspendLayout();
            OptionPanelMask6.SuspendLayout();
            white6.SuspendLayout();
            guna2Panel10.SuspendLayout();
            MainPanel.SuspendLayout();
            SuspendLayout();
            // 
            // guna2CircleButton1
            // 
            guna2CircleButton1.CheckedState.FillColor = Color.Lime;
            guna2CircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton1.FillColor = Color.FromArgb(212, 5, 17);
            guna2CircleButton1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton1.ForeColor = Color.White;
            guna2CircleButton1.Image = Properties.Resources.plus;
            guna2CircleButton1.ImageSize = new Size(16, 16);
            guna2CircleButton1.Location = new Point(589, 353);
            guna2CircleButton1.Name = "guna2CircleButton1";
            guna2CircleButton1.PressedColor = Color.Transparent;
            guna2CircleButton1.PressedDepth = 0;
            guna2CircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton1.Size = new Size(24, 24);
            guna2CircleButton1.TabIndex = 13;
            guna2CircleButton1.Click += guna2CircleButton1_Click;
            // 
            // guna2ImageButton1
            // 
            guna2ImageButton1.BackColor = Color.Red;
            guna2ImageButton1.CheckedState.ImageSize = new Size(64, 64);
            guna2ImageButton1.HoverState.ImageSize = new Size(64, 64);
            guna2ImageButton1.Image = Properties.Resources.galochka;
            guna2ImageButton1.ImageOffset = new Point(0, 0);
            guna2ImageButton1.ImageRotate = 0F;
            guna2ImageButton1.ImageSize = new Size(16, 16);
            guna2ImageButton1.Location = new Point(598, 401);
            guna2ImageButton1.Name = "guna2ImageButton1";
            guna2ImageButton1.PressedState.ImageSize = new Size(64, 64);
            guna2ImageButton1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2ImageButton1.Size = new Size(64, 54);
            guna2ImageButton1.TabIndex = 12;
            // 
            // OptionPanelBase1
            // 
            OptionPanelBase1.Anchor = AnchorStyles.None;
            OptionPanelBase1.BackColor = Color.Transparent;
            OptionPanelBase1.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase1.BorderRadius = 6;
            OptionPanelBase1.Clicked = false;
            OptionPanelBase1.Controls.Add(OptionPanelMask1);
            OptionPanelBase1.Controls.Add(OptinPanelWhitePanel1);
            OptionPanelBase1.Controls.Add(OptionPanelHeader1);
            OptionPanelBase1.CustomizableEdges = customizableEdges11;
            OptionPanelBase1.Location = new Point(6, 64);
            OptionPanelBase1.Name = "OptionPanelBase1";
            OptionPanelBase1.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase1.ShadowDecoration.CustomizableEdges = customizableEdges12;
            OptionPanelBase1.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase1.Size = new Size(166, 214);
            OptionPanelBase1.TabIndex = 15;
            OptionPanelBase1.UseTransparentBackground = true;
            // 
            // OptionPanelMask1
            // 
            OptionPanelMask1.BackColor = Color.Transparent;
            OptionPanelMask1.BorderRadius = 9;
            OptionPanelMask1.Clicked = false;
            OptionPanelMask1.Controls.Add(OptionPanelButton1);
            OptionPanelMask1.CustomizableEdges = customizableEdges5;
            OptionPanelMask1.Dock = DockStyle.Fill;
            OptionPanelMask1.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask1.Location = new Point(0, 0);
            OptionPanelMask1.Name = "OptionPanelMask1";
            OptionPanelMask1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            OptionPanelMask1.Size = new Size(166, 214);
            OptionPanelMask1.TabIndex = 10;
            OptionPanelMask1.UseTransparentBackground = true;
            // 
            // OptionPanelButton1
            // 
            OptionPanelButton1.BorderColor = Color.Transparent;
            OptionPanelButton1.BorderRadius = 5;
            OptionPanelButton1.BorderThickness = 2;
            OptionPanelButton1.CustomizableEdges = customizableEdges3;
            OptionPanelButton1.DisabledState.BorderColor = Color.DarkGray;
            OptionPanelButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            OptionPanelButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            OptionPanelButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            OptionPanelButton1.FillColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelButton1.ForeColor = Color.White;
            OptionPanelButton1.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton1.HoverState.FillColor = SystemColors.Control;
            OptionPanelButton1.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton1.IsHovered = false;
            OptionPanelButton1.Location = new Point(28, 168);
            OptionPanelButton1.Name = "OptionPanelButton1";
            OptionPanelButton1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            OptionPanelButton1.Size = new Size(110, 28);
            OptionPanelButton1.TabIndex = 17;
            OptionPanelButton1.Text = "PICK";
            // 
            // OptinPanelWhitePanel1
            // 
            OptinPanelWhitePanel1.BackColor = Color.Transparent;
            OptinPanelWhitePanel1.BorderColor = SystemColors.Control;
            OptinPanelWhitePanel1.BorderRadius = 9;
            OptinPanelWhitePanel1.BorderThickness = 1;
            OptinPanelWhitePanel1.Controls.Add(OptionPanelTraking1);
            OptinPanelWhitePanel1.Controls.Add(OptionPanelLiability1);
            OptinPanelWhitePanel1.Controls.Add(OptionPanelSizeDescription1);
            OptinPanelWhitePanel1.Controls.Add(OptionPanelName1);
            customizableEdges7.TopLeft = false;
            customizableEdges7.TopRight = false;
            OptinPanelWhitePanel1.CustomizableEdges = customizableEdges7;
            OptinPanelWhitePanel1.FillColor = SystemColors.Control;
            OptinPanelWhitePanel1.Location = new Point(2, 54);
            OptinPanelWhitePanel1.Name = "OptinPanelWhitePanel1";
            OptinPanelWhitePanel1.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            OptinPanelWhitePanel1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            OptinPanelWhitePanel1.Size = new Size(162, 158);
            OptinPanelWhitePanel1.TabIndex = 9;
            OptinPanelWhitePanel1.UseTransparentBackground = true;
            // 
            // OptionPanelTraking1
            // 
            OptionPanelTraking1.AutoSize = true;
            OptionPanelTraking1.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking1.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking1.Image = Properties.Resources.rotCross1;
            OptionPanelTraking1.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking1.Location = new Point(14, 83);
            OptionPanelTraking1.Name = "OptionPanelTraking1";
            OptionPanelTraking1.Size = new Size(116, 15);
            OptionPanelTraking1.TabIndex = 10;
            OptionPanelTraking1.Text = "    Shipment tracking";
            OptionPanelTraking1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability1
            // 
            OptionPanelLiability1.AutoSize = true;
            OptionPanelLiability1.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability1.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability1.Image = Properties.Resources.rotCross1;
            OptionPanelLiability1.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability1.Location = new Point(14, 65);
            OptionPanelLiability1.Name = "OptionPanelLiability1";
            OptionPanelLiability1.Size = new Size(60, 15);
            OptionPanelLiability1.TabIndex = 9;
            OptionPanelLiability1.Text = "    Liability";
            OptionPanelLiability1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription1
            // 
            OptionPanelSizeDescription1.AutoSize = true;
            OptionPanelSizeDescription1.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription1.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription1.Location = new Point(25, 46);
            OptionPanelSizeDescription1.Name = "OptionPanelSizeDescription1";
            OptionPanelSizeDescription1.Size = new Size(113, 15);
            OptionPanelSizeDescription1.TabIndex = 8;
            OptionPanelSizeDescription1.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName1
            // 
            OptionPanelName1.BackColor = Color.Transparent;
            OptionPanelName1.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName1.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName1.Location = new Point(1, 8);
            OptionPanelName1.Name = "OptionPanelName1";
            OptionPanelName1.Size = new Size(160, 32);
            OptionPanelName1.TabIndex = 7;
            OptionPanelName1.Text = "2 kg - Package S";
            OptionPanelName1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelHeader1
            // 
            OptionPanelHeader1.BackColor = Color.Transparent;
            OptionPanelHeader1.BorderColor = Color.FromArgb(255, 204, 0);
            OptionPanelHeader1.BorderRadius = 9;
            OptionPanelHeader1.BorderThickness = 1;
            OptionPanelHeader1.Controls.Add(OptionPanelPrice1);
            OptionPanelHeader1.CustomizableEdges = customizableEdges9;
            OptionPanelHeader1.FillColor = Color.FromArgb(255, 204, 0);
            OptionPanelHeader1.Location = new Point(2, 2);
            OptionPanelHeader1.Name = "OptionPanelHeader1";
            OptionPanelHeader1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            OptionPanelHeader1.Size = new Size(162, 82);
            OptionPanelHeader1.TabIndex = 0;
            OptionPanelHeader1.UseTransparentBackground = true;
            // 
            // OptionPanelPrice1
            // 
            OptionPanelPrice1.BackColor = Color.Transparent;
            OptionPanelPrice1.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelPrice1.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelPrice1.Location = new Point(1, 9);
            OptionPanelPrice1.Name = "OptionPanelPrice1";
            OptionPanelPrice1.Size = new Size(160, 32);
            OptionPanelPrice1.TabIndex = 6;
            OptionPanelPrice1.Text = "3,99 €";
            OptionPanelPrice1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelBase2
            // 
            OptionPanelBase2.Anchor = AnchorStyles.None;
            OptionPanelBase2.BackColor = Color.Transparent;
            OptionPanelBase2.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase2.BorderRadius = 6;
            OptionPanelBase2.Clicked = false;
            OptionPanelBase2.Controls.Add(OptionPanelMask2);
            OptionPanelBase2.Controls.Add(white2);
            OptionPanelBase2.Controls.Add(guna2Panel2);
            OptionPanelBase2.CustomizableEdges = customizableEdges21;
            OptionPanelBase2.Location = new Point(185, 64);
            OptionPanelBase2.Name = "OptionPanelBase2";
            OptionPanelBase2.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase2.ShadowDecoration.CustomizableEdges = customizableEdges22;
            OptionPanelBase2.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase2.Size = new Size(166, 214);
            OptionPanelBase2.TabIndex = 16;
            OptionPanelBase2.UseTransparentBackground = true;
            // 
            // OptionPanelMask2
            // 
            OptionPanelMask2.BackColor = Color.Transparent;
            OptionPanelMask2.BorderRadius = 9;
            OptionPanelMask2.Clicked = false;
            OptionPanelMask2.Controls.Add(hoverButton1);
            OptionPanelMask2.CustomizableEdges = customizableEdges15;
            OptionPanelMask2.Dock = DockStyle.Fill;
            OptionPanelMask2.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask2.Location = new Point(0, 0);
            OptionPanelMask2.Name = "OptionPanelMask2";
            OptionPanelMask2.ShadowDecoration.CustomizableEdges = customizableEdges16;
            OptionPanelMask2.Size = new Size(166, 214);
            OptionPanelMask2.TabIndex = 10;
            OptionPanelMask2.UseTransparentBackground = true;
            // 
            // hoverButton1
            // 
            hoverButton1.BorderColor = Color.Transparent;
            hoverButton1.BorderRadius = 5;
            hoverButton1.BorderThickness = 2;
            hoverButton1.CustomizableEdges = customizableEdges13;
            hoverButton1.DisabledState.BorderColor = Color.DarkGray;
            hoverButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            hoverButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            hoverButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            hoverButton1.FillColor = Color.FromArgb(212, 5, 17);
            hoverButton1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            hoverButton1.ForeColor = Color.White;
            hoverButton1.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            hoverButton1.HoverState.FillColor = SystemColors.Control;
            hoverButton1.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            hoverButton1.IsHovered = false;
            hoverButton1.Location = new Point(28, 168);
            hoverButton1.Name = "hoverButton1";
            hoverButton1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            hoverButton1.Size = new Size(110, 28);
            hoverButton1.TabIndex = 17;
            hoverButton1.Text = "PICK";
            // 
            // white2
            // 
            white2.BackColor = Color.Transparent;
            white2.BorderColor = SystemColors.Control;
            white2.BorderRadius = 9;
            white2.BorderThickness = 1;
            white2.Controls.Add(OptionPanelTraking2);
            white2.Controls.Add(OptionPanelLiability2);
            white2.Controls.Add(OptionPanelSizeDescription2);
            white2.Controls.Add(OptionPanelName2);
            customizableEdges17.TopLeft = false;
            customizableEdges17.TopRight = false;
            white2.CustomizableEdges = customizableEdges17;
            white2.FillColor = SystemColors.Control;
            white2.Location = new Point(2, 54);
            white2.Name = "white2";
            white2.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            white2.ShadowDecoration.CustomizableEdges = customizableEdges18;
            white2.Size = new Size(162, 158);
            white2.TabIndex = 9;
            white2.UseTransparentBackground = true;
            // 
            // OptionPanelTraking2
            // 
            OptionPanelTraking2.AutoSize = true;
            OptionPanelTraking2.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking2.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking2.Image = Properties.Resources.rotCross1;
            OptionPanelTraking2.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking2.Location = new Point(14, 83);
            OptionPanelTraking2.Name = "OptionPanelTraking2";
            OptionPanelTraking2.Size = new Size(116, 15);
            OptionPanelTraking2.TabIndex = 10;
            OptionPanelTraking2.Text = "    Shipment tracking";
            OptionPanelTraking2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability2
            // 
            OptionPanelLiability2.AutoSize = true;
            OptionPanelLiability2.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability2.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability2.Image = Properties.Resources.rotCross1;
            OptionPanelLiability2.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability2.Location = new Point(14, 65);
            OptionPanelLiability2.Name = "OptionPanelLiability2";
            OptionPanelLiability2.Size = new Size(60, 15);
            OptionPanelLiability2.TabIndex = 9;
            OptionPanelLiability2.Text = "    Liability";
            OptionPanelLiability2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription2
            // 
            OptionPanelSizeDescription2.AutoSize = true;
            OptionPanelSizeDescription2.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription2.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription2.Location = new Point(25, 46);
            OptionPanelSizeDescription2.Name = "OptionPanelSizeDescription2";
            OptionPanelSizeDescription2.Size = new Size(113, 15);
            OptionPanelSizeDescription2.TabIndex = 8;
            OptionPanelSizeDescription2.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName2
            // 
            OptionPanelName2.BackColor = Color.Transparent;
            OptionPanelName2.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName2.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName2.Location = new Point(1, 8);
            OptionPanelName2.Name = "OptionPanelName2";
            OptionPanelName2.Size = new Size(160, 32);
            OptionPanelName2.TabIndex = 7;
            OptionPanelName2.Text = "2 kg - Package S";
            OptionPanelName2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.Transparent;
            guna2Panel2.BorderColor = Color.FromArgb(255, 204, 0);
            guna2Panel2.BorderRadius = 9;
            guna2Panel2.BorderThickness = 1;
            guna2Panel2.Controls.Add(OptionPanelPrice2);
            guna2Panel2.CustomizableEdges = customizableEdges19;
            guna2Panel2.FillColor = Color.FromArgb(255, 204, 0);
            guna2Panel2.Location = new Point(2, 2);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Panel2.Size = new Size(162, 82);
            guna2Panel2.TabIndex = 0;
            guna2Panel2.UseTransparentBackground = true;
            // 
            // OptionPanelPrice2
            // 
            OptionPanelPrice2.BackColor = Color.Transparent;
            OptionPanelPrice2.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelPrice2.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelPrice2.Location = new Point(1, 9);
            OptionPanelPrice2.Name = "OptionPanelPrice2";
            OptionPanelPrice2.Size = new Size(160, 32);
            OptionPanelPrice2.TabIndex = 6;
            OptionPanelPrice2.Text = "3,99 €";
            OptionPanelPrice2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelBase3
            // 
            OptionPanelBase3.Anchor = AnchorStyles.None;
            OptionPanelBase3.BackColor = Color.Transparent;
            OptionPanelBase3.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase3.BorderRadius = 6;
            OptionPanelBase3.Clicked = false;
            OptionPanelBase3.Controls.Add(OptionPanelMask3);
            OptionPanelBase3.Controls.Add(white3);
            OptionPanelBase3.Controls.Add(guna2Panel4);
            OptionPanelBase3.CustomizableEdges = customizableEdges31;
            OptionPanelBase3.Location = new Point(368, 64);
            OptionPanelBase3.Name = "OptionPanelBase3";
            OptionPanelBase3.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase3.ShadowDecoration.CustomizableEdges = customizableEdges32;
            OptionPanelBase3.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase3.Size = new Size(166, 214);
            OptionPanelBase3.TabIndex = 17;
            OptionPanelBase3.UseTransparentBackground = true;
            // 
            // OptionPanelMask3
            // 
            OptionPanelMask3.BackColor = Color.Transparent;
            OptionPanelMask3.BorderRadius = 9;
            OptionPanelMask3.Clicked = false;
            OptionPanelMask3.Controls.Add(OptionPanelButton3);
            OptionPanelMask3.CustomizableEdges = customizableEdges25;
            OptionPanelMask3.Dock = DockStyle.Fill;
            OptionPanelMask3.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask3.Location = new Point(0, 0);
            OptionPanelMask3.Name = "OptionPanelMask3";
            OptionPanelMask3.ShadowDecoration.CustomizableEdges = customizableEdges26;
            OptionPanelMask3.Size = new Size(166, 214);
            OptionPanelMask3.TabIndex = 10;
            OptionPanelMask3.UseTransparentBackground = true;
            // 
            // OptionPanelButton3
            // 
            OptionPanelButton3.BorderColor = Color.Transparent;
            OptionPanelButton3.BorderRadius = 5;
            OptionPanelButton3.BorderThickness = 2;
            OptionPanelButton3.CustomizableEdges = customizableEdges23;
            OptionPanelButton3.DisabledState.BorderColor = Color.DarkGray;
            OptionPanelButton3.DisabledState.CustomBorderColor = Color.DarkGray;
            OptionPanelButton3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            OptionPanelButton3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            OptionPanelButton3.FillColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton3.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelButton3.ForeColor = Color.White;
            OptionPanelButton3.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton3.HoverState.FillColor = SystemColors.Control;
            OptionPanelButton3.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton3.IsHovered = false;
            OptionPanelButton3.Location = new Point(28, 168);
            OptionPanelButton3.Name = "OptionPanelButton3";
            OptionPanelButton3.ShadowDecoration.CustomizableEdges = customizableEdges24;
            OptionPanelButton3.Size = new Size(110, 28);
            OptionPanelButton3.TabIndex = 17;
            OptionPanelButton3.Text = "PICK";
            // 
            // white3
            // 
            white3.BackColor = Color.Transparent;
            white3.BorderColor = SystemColors.Control;
            white3.BorderRadius = 9;
            white3.BorderThickness = 1;
            white3.Controls.Add(OptionPanelTraking3);
            white3.Controls.Add(OptionPanelLiability3);
            white3.Controls.Add(OptionPanelSizeDescription3);
            white3.Controls.Add(OptionPanelName3);
            customizableEdges27.TopLeft = false;
            customizableEdges27.TopRight = false;
            white3.CustomizableEdges = customizableEdges27;
            white3.FillColor = SystemColors.Control;
            white3.Location = new Point(2, 54);
            white3.Name = "white3";
            white3.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            white3.ShadowDecoration.CustomizableEdges = customizableEdges28;
            white3.Size = new Size(162, 158);
            white3.TabIndex = 9;
            white3.UseTransparentBackground = true;
            // 
            // OptionPanelTraking3
            // 
            OptionPanelTraking3.AutoSize = true;
            OptionPanelTraking3.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking3.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking3.Image = Properties.Resources.rotCross1;
            OptionPanelTraking3.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking3.Location = new Point(14, 83);
            OptionPanelTraking3.Name = "OptionPanelTraking3";
            OptionPanelTraking3.Size = new Size(116, 15);
            OptionPanelTraking3.TabIndex = 10;
            OptionPanelTraking3.Text = "    Shipment tracking";
            OptionPanelTraking3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability3
            // 
            OptionPanelLiability3.AutoSize = true;
            OptionPanelLiability3.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability3.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability3.Image = Properties.Resources.rotCross1;
            OptionPanelLiability3.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability3.Location = new Point(14, 65);
            OptionPanelLiability3.Name = "OptionPanelLiability3";
            OptionPanelLiability3.Size = new Size(60, 15);
            OptionPanelLiability3.TabIndex = 9;
            OptionPanelLiability3.Text = "    Liability";
            OptionPanelLiability3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription3
            // 
            OptionPanelSizeDescription3.AutoSize = true;
            OptionPanelSizeDescription3.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription3.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription3.Location = new Point(25, 46);
            OptionPanelSizeDescription3.Name = "OptionPanelSizeDescription3";
            OptionPanelSizeDescription3.Size = new Size(113, 15);
            OptionPanelSizeDescription3.TabIndex = 8;
            OptionPanelSizeDescription3.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName3
            // 
            OptionPanelName3.BackColor = Color.Transparent;
            OptionPanelName3.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName3.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName3.Location = new Point(1, 8);
            OptionPanelName3.Name = "OptionPanelName3";
            OptionPanelName3.Size = new Size(160, 32);
            OptionPanelName3.TabIndex = 7;
            OptionPanelName3.Text = "2 kg - Package S";
            OptionPanelName3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel4
            // 
            guna2Panel4.BackColor = Color.Transparent;
            guna2Panel4.BorderColor = Color.FromArgb(255, 204, 0);
            guna2Panel4.BorderRadius = 9;
            guna2Panel4.BorderThickness = 1;
            guna2Panel4.Controls.Add(label10OptionPanelPrice3);
            guna2Panel4.CustomizableEdges = customizableEdges29;
            guna2Panel4.FillColor = Color.FromArgb(255, 204, 0);
            guna2Panel4.Location = new Point(2, 2);
            guna2Panel4.Name = "guna2Panel4";
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges30;
            guna2Panel4.Size = new Size(162, 82);
            guna2Panel4.TabIndex = 0;
            guna2Panel4.UseTransparentBackground = true;
            // 
            // label10OptionPanelPrice3
            // 
            label10OptionPanelPrice3.BackColor = Color.Transparent;
            label10OptionPanelPrice3.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label10OptionPanelPrice3.ForeColor = Color.FromArgb(50, 50, 50);
            label10OptionPanelPrice3.Location = new Point(1, 9);
            label10OptionPanelPrice3.Name = "label10OptionPanelPrice3";
            label10OptionPanelPrice3.Size = new Size(160, 32);
            label10OptionPanelPrice3.TabIndex = 6;
            label10OptionPanelPrice3.Text = "3,99 €";
            label10OptionPanelPrice3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelBase5
            // 
            OptionPanelBase5.Anchor = AnchorStyles.None;
            OptionPanelBase5.BackColor = Color.Transparent;
            OptionPanelBase5.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase5.BorderRadius = 6;
            OptionPanelBase5.Clicked = false;
            OptionPanelBase5.Controls.Add(OptionPanelMask5);
            OptionPanelBase5.Controls.Add(white5);
            OptionPanelBase5.Controls.Add(guna2Panel6);
            OptionPanelBase5.CustomizableEdges = customizableEdges41;
            OptionPanelBase5.Location = new Point(736, 66);
            OptionPanelBase5.Name = "OptionPanelBase5";
            OptionPanelBase5.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase5.ShadowDecoration.CustomizableEdges = customizableEdges42;
            OptionPanelBase5.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase5.Size = new Size(166, 214);
            OptionPanelBase5.TabIndex = 18;
            OptionPanelBase5.UseTransparentBackground = true;
            // 
            // OptionPanelMask5
            // 
            OptionPanelMask5.BackColor = Color.Transparent;
            OptionPanelMask5.BorderRadius = 9;
            OptionPanelMask5.Clicked = false;
            OptionPanelMask5.Controls.Add(OptionPanelButton5);
            OptionPanelMask5.CustomizableEdges = customizableEdges35;
            OptionPanelMask5.Dock = DockStyle.Fill;
            OptionPanelMask5.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask5.Location = new Point(0, 0);
            OptionPanelMask5.Name = "OptionPanelMask5";
            OptionPanelMask5.ShadowDecoration.CustomizableEdges = customizableEdges36;
            OptionPanelMask5.Size = new Size(166, 214);
            OptionPanelMask5.TabIndex = 10;
            OptionPanelMask5.UseTransparentBackground = true;
            // 
            // OptionPanelButton5
            // 
            OptionPanelButton5.BorderColor = Color.Transparent;
            OptionPanelButton5.BorderRadius = 5;
            OptionPanelButton5.BorderThickness = 2;
            OptionPanelButton5.CustomizableEdges = customizableEdges33;
            OptionPanelButton5.DisabledState.BorderColor = Color.DarkGray;
            OptionPanelButton5.DisabledState.CustomBorderColor = Color.DarkGray;
            OptionPanelButton5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            OptionPanelButton5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            OptionPanelButton5.FillColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton5.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelButton5.ForeColor = Color.White;
            OptionPanelButton5.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton5.HoverState.FillColor = SystemColors.Control;
            OptionPanelButton5.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton5.IsHovered = false;
            OptionPanelButton5.Location = new Point(28, 168);
            OptionPanelButton5.Name = "OptionPanelButton5";
            OptionPanelButton5.ShadowDecoration.CustomizableEdges = customizableEdges34;
            OptionPanelButton5.Size = new Size(110, 28);
            OptionPanelButton5.TabIndex = 17;
            OptionPanelButton5.Text = "PICK";
            // 
            // white5
            // 
            white5.BackColor = Color.Transparent;
            white5.BorderColor = SystemColors.Control;
            white5.BorderRadius = 9;
            white5.BorderThickness = 1;
            white5.Controls.Add(OptionPanelTraking5);
            white5.Controls.Add(OptionPanelLiability5);
            white5.Controls.Add(OptionPanelSizeDescription5);
            white5.Controls.Add(OptionPanelName5);
            customizableEdges37.TopLeft = false;
            customizableEdges37.TopRight = false;
            white5.CustomizableEdges = customizableEdges37;
            white5.FillColor = SystemColors.Control;
            white5.Location = new Point(2, 54);
            white5.Name = "white5";
            white5.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            white5.ShadowDecoration.CustomizableEdges = customizableEdges38;
            white5.Size = new Size(162, 158);
            white5.TabIndex = 9;
            white5.UseTransparentBackground = true;
            // 
            // OptionPanelTraking5
            // 
            OptionPanelTraking5.AutoSize = true;
            OptionPanelTraking5.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking5.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking5.Image = Properties.Resources.rotCross1;
            OptionPanelTraking5.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking5.Location = new Point(14, 83);
            OptionPanelTraking5.Name = "OptionPanelTraking5";
            OptionPanelTraking5.Size = new Size(116, 15);
            OptionPanelTraking5.TabIndex = 10;
            OptionPanelTraking5.Text = "    Shipment tracking";
            OptionPanelTraking5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability5
            // 
            OptionPanelLiability5.AutoSize = true;
            OptionPanelLiability5.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability5.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability5.Image = Properties.Resources.rotCross1;
            OptionPanelLiability5.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability5.Location = new Point(14, 65);
            OptionPanelLiability5.Name = "OptionPanelLiability5";
            OptionPanelLiability5.Size = new Size(60, 15);
            OptionPanelLiability5.TabIndex = 9;
            OptionPanelLiability5.Text = "    Liability";
            OptionPanelLiability5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription5
            // 
            OptionPanelSizeDescription5.AutoSize = true;
            OptionPanelSizeDescription5.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription5.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription5.Location = new Point(25, 46);
            OptionPanelSizeDescription5.Name = "OptionPanelSizeDescription5";
            OptionPanelSizeDescription5.Size = new Size(113, 15);
            OptionPanelSizeDescription5.TabIndex = 8;
            OptionPanelSizeDescription5.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName5
            // 
            OptionPanelName5.BackColor = Color.Transparent;
            OptionPanelName5.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName5.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName5.Location = new Point(1, 8);
            OptionPanelName5.Name = "OptionPanelName5";
            OptionPanelName5.Size = new Size(160, 32);
            OptionPanelName5.TabIndex = 7;
            OptionPanelName5.Text = "2 kg - Package S";
            OptionPanelName5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel6
            // 
            guna2Panel6.BackColor = Color.Transparent;
            guna2Panel6.BorderColor = Color.FromArgb(255, 204, 0);
            guna2Panel6.BorderRadius = 9;
            guna2Panel6.BorderThickness = 1;
            guna2Panel6.Controls.Add(OptionPanelPrice5);
            guna2Panel6.CustomizableEdges = customizableEdges39;
            guna2Panel6.FillColor = Color.FromArgb(255, 204, 0);
            guna2Panel6.Location = new Point(2, 2);
            guna2Panel6.Name = "guna2Panel6";
            guna2Panel6.ShadowDecoration.CustomizableEdges = customizableEdges40;
            guna2Panel6.Size = new Size(162, 82);
            guna2Panel6.TabIndex = 0;
            guna2Panel6.UseTransparentBackground = true;
            // 
            // OptionPanelPrice5
            // 
            OptionPanelPrice5.BackColor = Color.Transparent;
            OptionPanelPrice5.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelPrice5.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelPrice5.Location = new Point(1, 9);
            OptionPanelPrice5.Name = "OptionPanelPrice5";
            OptionPanelPrice5.Size = new Size(160, 32);
            OptionPanelPrice5.TabIndex = 6;
            OptionPanelPrice5.Text = "3,99 €";
            OptionPanelPrice5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelBase4
            // 
            OptionPanelBase4.Anchor = AnchorStyles.None;
            OptionPanelBase4.BackColor = Color.Transparent;
            OptionPanelBase4.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase4.BorderRadius = 6;
            OptionPanelBase4.Clicked = false;
            OptionPanelBase4.Controls.Add(OptionPanelMask4);
            OptionPanelBase4.Controls.Add(white4);
            OptionPanelBase4.Controls.Add(guna2Panel8);
            OptionPanelBase4.CustomizableEdges = customizableEdges51;
            OptionPanelBase4.Location = new Point(555, 66);
            OptionPanelBase4.Name = "OptionPanelBase4";
            OptionPanelBase4.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase4.ShadowDecoration.CustomizableEdges = customizableEdges52;
            OptionPanelBase4.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase4.Size = new Size(166, 214);
            OptionPanelBase4.TabIndex = 19;
            OptionPanelBase4.UseTransparentBackground = true;
            // 
            // OptionPanelMask4
            // 
            OptionPanelMask4.BackColor = Color.Transparent;
            OptionPanelMask4.BorderRadius = 9;
            OptionPanelMask4.Clicked = false;
            OptionPanelMask4.Controls.Add(OptionPanelButton4);
            OptionPanelMask4.CustomizableEdges = customizableEdges45;
            OptionPanelMask4.Dock = DockStyle.Fill;
            OptionPanelMask4.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask4.Location = new Point(0, 0);
            OptionPanelMask4.Name = "OptionPanelMask4";
            OptionPanelMask4.ShadowDecoration.CustomizableEdges = customizableEdges46;
            OptionPanelMask4.Size = new Size(166, 214);
            OptionPanelMask4.TabIndex = 10;
            OptionPanelMask4.UseTransparentBackground = true;
            // 
            // OptionPanelButton4
            // 
            OptionPanelButton4.BorderColor = Color.Transparent;
            OptionPanelButton4.BorderRadius = 5;
            OptionPanelButton4.BorderThickness = 2;
            OptionPanelButton4.CustomizableEdges = customizableEdges43;
            OptionPanelButton4.DisabledState.BorderColor = Color.DarkGray;
            OptionPanelButton4.DisabledState.CustomBorderColor = Color.DarkGray;
            OptionPanelButton4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            OptionPanelButton4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            OptionPanelButton4.FillColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton4.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelButton4.ForeColor = Color.White;
            OptionPanelButton4.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton4.HoverState.FillColor = SystemColors.Control;
            OptionPanelButton4.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton4.IsHovered = false;
            OptionPanelButton4.Location = new Point(28, 168);
            OptionPanelButton4.Name = "OptionPanelButton4";
            OptionPanelButton4.ShadowDecoration.CustomizableEdges = customizableEdges44;
            OptionPanelButton4.Size = new Size(110, 28);
            OptionPanelButton4.TabIndex = 17;
            OptionPanelButton4.Text = "PICK";
            // 
            // white4
            // 
            white4.BackColor = Color.Transparent;
            white4.BorderColor = SystemColors.Control;
            white4.BorderRadius = 9;
            white4.BorderThickness = 1;
            white4.Controls.Add(OptionPanelTraking4);
            white4.Controls.Add(OptionPanelLiability4);
            white4.Controls.Add(OptionPanelSizeDescription4);
            white4.Controls.Add(OptionPanelName4);
            customizableEdges47.TopLeft = false;
            customizableEdges47.TopRight = false;
            white4.CustomizableEdges = customizableEdges47;
            white4.FillColor = SystemColors.Control;
            white4.Location = new Point(2, 54);
            white4.Name = "white4";
            white4.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            white4.ShadowDecoration.CustomizableEdges = customizableEdges48;
            white4.Size = new Size(162, 158);
            white4.TabIndex = 9;
            white4.UseTransparentBackground = true;
            // 
            // OptionPanelTraking4
            // 
            OptionPanelTraking4.AutoSize = true;
            OptionPanelTraking4.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking4.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking4.Image = Properties.Resources.rotCross1;
            OptionPanelTraking4.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking4.Location = new Point(14, 83);
            OptionPanelTraking4.Name = "OptionPanelTraking4";
            OptionPanelTraking4.Size = new Size(116, 15);
            OptionPanelTraking4.TabIndex = 10;
            OptionPanelTraking4.Text = "    Shipment tracking";
            OptionPanelTraking4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability4
            // 
            OptionPanelLiability4.AutoSize = true;
            OptionPanelLiability4.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability4.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability4.Image = Properties.Resources.rotCross1;
            OptionPanelLiability4.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability4.Location = new Point(14, 65);
            OptionPanelLiability4.Name = "OptionPanelLiability4";
            OptionPanelLiability4.Size = new Size(60, 15);
            OptionPanelLiability4.TabIndex = 9;
            OptionPanelLiability4.Text = "    Liability";
            OptionPanelLiability4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription4
            // 
            OptionPanelSizeDescription4.AutoSize = true;
            OptionPanelSizeDescription4.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription4.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription4.Location = new Point(25, 46);
            OptionPanelSizeDescription4.Name = "OptionPanelSizeDescription4";
            OptionPanelSizeDescription4.Size = new Size(113, 15);
            OptionPanelSizeDescription4.TabIndex = 8;
            OptionPanelSizeDescription4.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName4
            // 
            OptionPanelName4.BackColor = Color.Transparent;
            OptionPanelName4.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName4.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName4.Location = new Point(1, 8);
            OptionPanelName4.Name = "OptionPanelName4";
            OptionPanelName4.Size = new Size(160, 32);
            OptionPanelName4.TabIndex = 7;
            OptionPanelName4.Text = "2 kg - Package S";
            OptionPanelName4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel8
            // 
            guna2Panel8.BackColor = Color.Transparent;
            guna2Panel8.BorderColor = Color.FromArgb(255, 204, 0);
            guna2Panel8.BorderRadius = 9;
            guna2Panel8.BorderThickness = 1;
            guna2Panel8.Controls.Add(OptionPanelPrice4);
            guna2Panel8.CustomizableEdges = customizableEdges49;
            guna2Panel8.FillColor = Color.FromArgb(255, 204, 0);
            guna2Panel8.Location = new Point(2, 2);
            guna2Panel8.Name = "guna2Panel8";
            guna2Panel8.ShadowDecoration.CustomizableEdges = customizableEdges50;
            guna2Panel8.Size = new Size(162, 82);
            guna2Panel8.TabIndex = 0;
            guna2Panel8.UseTransparentBackground = true;
            // 
            // OptionPanelPrice4
            // 
            OptionPanelPrice4.BackColor = Color.Transparent;
            OptionPanelPrice4.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelPrice4.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelPrice4.Location = new Point(1, 9);
            OptionPanelPrice4.Name = "OptionPanelPrice4";
            OptionPanelPrice4.Size = new Size(160, 32);
            OptionPanelPrice4.TabIndex = 6;
            OptionPanelPrice4.Text = "3,99 €";
            OptionPanelPrice4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnNextPage
            // 
            btnNextPage.Animated = true;
            btnNextPage.BorderColor = Color.Transparent;
            btnNextPage.BorderRadius = 3;
            btnNextPage.BorderThickness = 2;
            btnNextPage.CheckedState.BorderColor = Color.FromArgb(212, 5, 17);
            btnNextPage.CheckedState.FillColor = SystemColors.Control;
            btnNextPage.CheckedState.ForeColor = Color.FromArgb(212, 5, 17);
            btnNextPage.CustomizableEdges = customizableEdges53;
            btnNextPage.DisabledState.BorderColor = Color.DarkGray;
            btnNextPage.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNextPage.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNextPage.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNextPage.FillColor = Color.FromArgb(212, 5, 17);
            btnNextPage.Font = new Font("Calibri", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnNextPage.ForeColor = Color.White;
            btnNextPage.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            btnNextPage.HoverState.FillColor = Color.Transparent;
            btnNextPage.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            btnNextPage.Location = new Point(19, 542);
            btnNextPage.Name = "btnNextPage";
            btnNextPage.ShadowDecoration.CustomizableEdges = customizableEdges54;
            btnNextPage.Size = new Size(345, 39);
            btnNextPage.TabIndex = 11;
            btnNextPage.Text = "Continue to address input";
            btnNextPage.Click += guna2Button7_Click;
            // 
            // OptionPanelBase6
            // 
            OptionPanelBase6.Anchor = AnchorStyles.None;
            OptionPanelBase6.AutoScroll = true;
            OptionPanelBase6.BackColor = Color.Transparent;
            OptionPanelBase6.BorderColor = Color.FromArgb(94, 183, 97);
            OptionPanelBase6.BorderRadius = 6;
            OptionPanelBase6.Clicked = false;
            OptionPanelBase6.Controls.Add(OptionPanelMask6);
            OptionPanelBase6.Controls.Add(white6);
            OptionPanelBase6.Controls.Add(guna2Panel10);
            OptionPanelBase6.CustomizableEdges = customizableEdges63;
            OptionPanelBase6.Location = new Point(395, 313);
            OptionPanelBase6.Name = "OptionPanelBase6";
            OptionPanelBase6.ShadowDecoration.BorderRadius = 12;
            OptionPanelBase6.ShadowDecoration.CustomizableEdges = customizableEdges64;
            OptionPanelBase6.ShadowDecoration.Shadow = new Padding(5, 0, 5, 6);
            OptionPanelBase6.Size = new Size(166, 214);
            OptionPanelBase6.TabIndex = 20;
            OptionPanelBase6.UseTransparentBackground = true;
            // 
            // OptionPanelMask6
            // 
            OptionPanelMask6.BackColor = Color.Transparent;
            OptionPanelMask6.BorderRadius = 9;
            OptionPanelMask6.Clicked = false;
            OptionPanelMask6.Controls.Add(OptionPanelButton6);
            OptionPanelMask6.CustomizableEdges = customizableEdges57;
            OptionPanelMask6.Dock = DockStyle.Fill;
            OptionPanelMask6.ForeColor = SystemColors.ControlLightLight;
            OptionPanelMask6.Location = new Point(0, 0);
            OptionPanelMask6.Name = "OptionPanelMask6";
            OptionPanelMask6.ShadowDecoration.CustomizableEdges = customizableEdges58;
            OptionPanelMask6.Size = new Size(166, 214);
            OptionPanelMask6.TabIndex = 10;
            OptionPanelMask6.UseTransparentBackground = true;
            // 
            // OptionPanelButton6
            // 
            OptionPanelButton6.BorderColor = Color.Transparent;
            OptionPanelButton6.BorderRadius = 5;
            OptionPanelButton6.BorderThickness = 2;
            OptionPanelButton6.CustomizableEdges = customizableEdges55;
            OptionPanelButton6.DisabledState.BorderColor = Color.DarkGray;
            OptionPanelButton6.DisabledState.CustomBorderColor = Color.DarkGray;
            OptionPanelButton6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            OptionPanelButton6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            OptionPanelButton6.FillColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton6.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelButton6.ForeColor = Color.White;
            OptionPanelButton6.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton6.HoverState.FillColor = SystemColors.Control;
            OptionPanelButton6.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            OptionPanelButton6.IsHovered = false;
            OptionPanelButton6.Location = new Point(28, 168);
            OptionPanelButton6.Name = "OptionPanelButton6";
            OptionPanelButton6.ShadowDecoration.CustomizableEdges = customizableEdges56;
            OptionPanelButton6.Size = new Size(110, 28);
            OptionPanelButton6.TabIndex = 17;
            OptionPanelButton6.Text = "PICK";
            // 
            // white6
            // 
            white6.BackColor = Color.Transparent;
            white6.BorderColor = SystemColors.Control;
            white6.BorderRadius = 9;
            white6.BorderThickness = 1;
            white6.Controls.Add(OptionPanelTraking6);
            white6.Controls.Add(OptionPanelLiability6);
            white6.Controls.Add(OptionPanelSizeDescription6);
            white6.Controls.Add(OptionPanelName6);
            customizableEdges59.TopLeft = false;
            customizableEdges59.TopRight = false;
            white6.CustomizableEdges = customizableEdges59;
            white6.FillColor = SystemColors.Control;
            white6.Location = new Point(2, 54);
            white6.Name = "white6";
            white6.ShadowDecoration.Color = Color.FromArgb(64, 64, 64);
            white6.ShadowDecoration.CustomizableEdges = customizableEdges60;
            white6.Size = new Size(162, 158);
            white6.TabIndex = 9;
            white6.UseTransparentBackground = true;
            // 
            // OptionPanelTraking6
            // 
            OptionPanelTraking6.AutoSize = true;
            OptionPanelTraking6.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelTraking6.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelTraking6.Image = Properties.Resources.rotCross1;
            OptionPanelTraking6.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelTraking6.Location = new Point(14, 83);
            OptionPanelTraking6.Name = "OptionPanelTraking6";
            OptionPanelTraking6.Size = new Size(116, 15);
            OptionPanelTraking6.TabIndex = 10;
            OptionPanelTraking6.Text = "    Shipment tracking";
            OptionPanelTraking6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelLiability6
            // 
            OptionPanelLiability6.AutoSize = true;
            OptionPanelLiability6.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelLiability6.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelLiability6.Image = Properties.Resources.rotCross1;
            OptionPanelLiability6.ImageAlign = ContentAlignment.MiddleLeft;
            OptionPanelLiability6.Location = new Point(14, 65);
            OptionPanelLiability6.Name = "OptionPanelLiability6";
            OptionPanelLiability6.Size = new Size(60, 15);
            OptionPanelLiability6.TabIndex = 9;
            OptionPanelLiability6.Text = "    Liability";
            OptionPanelLiability6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // OptionPanelSizeDescription6
            // 
            OptionPanelSizeDescription6.AutoSize = true;
            OptionPanelSizeDescription6.Font = new Font("Leelawadee UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            OptionPanelSizeDescription6.ForeColor = Color.FromArgb(90, 90, 90);
            OptionPanelSizeDescription6.Location = new Point(25, 46);
            OptionPanelSizeDescription6.Name = "OptionPanelSizeDescription6";
            OptionPanelSizeDescription6.Size = new Size(113, 15);
            OptionPanelSizeDescription6.TabIndex = 8;
            OptionPanelSizeDescription6.Text = "max. 30 x 25 x 10 cm";
            // 
            // OptionPanelName6
            // 
            OptionPanelName6.BackColor = Color.Transparent;
            OptionPanelName6.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelName6.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelName6.Location = new Point(1, 8);
            OptionPanelName6.Name = "OptionPanelName6";
            OptionPanelName6.Size = new Size(160, 32);
            OptionPanelName6.TabIndex = 7;
            OptionPanelName6.Text = "2 kg - Package S";
            OptionPanelName6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel10
            // 
            guna2Panel10.BackColor = Color.Transparent;
            guna2Panel10.BorderColor = Color.FromArgb(255, 204, 0);
            guna2Panel10.BorderRadius = 9;
            guna2Panel10.BorderThickness = 1;
            guna2Panel10.Controls.Add(OptionPanelPrice6);
            guna2Panel10.CustomizableEdges = customizableEdges61;
            guna2Panel10.FillColor = Color.FromArgb(255, 204, 0);
            guna2Panel10.Location = new Point(2, 2);
            guna2Panel10.Name = "guna2Panel10";
            guna2Panel10.ShadowDecoration.CustomizableEdges = customizableEdges62;
            guna2Panel10.Size = new Size(162, 82);
            guna2Panel10.TabIndex = 0;
            guna2Panel10.UseTransparentBackground = true;
            // 
            // OptionPanelPrice6
            // 
            OptionPanelPrice6.BackColor = Color.Transparent;
            OptionPanelPrice6.Font = new Font("Leelawadee UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            OptionPanelPrice6.ForeColor = Color.FromArgb(50, 50, 50);
            OptionPanelPrice6.Location = new Point(1, 9);
            OptionPanelPrice6.Name = "OptionPanelPrice6";
            OptionPanelPrice6.Size = new Size(160, 32);
            OptionPanelPrice6.TabIndex = 6;
            OptionPanelPrice6.Text = "3,99 €";
            OptionPanelPrice6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel_login
            // 
            panel_login.BackColor = Color.FromArgb(70, 70, 70);
            panel_login.Location = new Point(6, 294);
            panel_login.Name = "panel_login";
            panel_login.Size = new Size(988, 1);
            panel_login.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Leelawadee UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(10, 10, 10);
            label1.Location = new Point(-1, 13);
            label1.Name = "label1";
            label1.Size = new Size(214, 40);
            label1.TabIndex = 22;
            label1.Text = "Product range";
            // 
            // MainPanel
            // 
            MainPanel.BackColor = Color.FromArgb(46, 51, 73);
            MainPanel.Controls.Add(label1);
            MainPanel.Controls.Add(panel_login);
            MainPanel.Controls.Add(OptionPanelBase6);
            MainPanel.Controls.Add(btnNextPage);
            MainPanel.Controls.Add(OptionPanelBase4);
            MainPanel.Controls.Add(OptionPanelBase5);
            MainPanel.Controls.Add(OptionPanelBase3);
            MainPanel.Controls.Add(OptionPanelBase2);
            MainPanel.Controls.Add(OptionPanelBase1);
            MainPanel.Controls.Add(guna2ImageButton1);
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(0, 0);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(1000, 600);
            MainPanel.TabIndex = 18;
            // 
            // NewPackageForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(1000, 600);
            Controls.Add(guna2CircleButton1);
            Controls.Add(MainPanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewPackageForm";
            Text = "NewPackageForm";
            OptionPanelBase1.ResumeLayout(false);
            OptionPanelMask1.ResumeLayout(false);
            OptinPanelWhitePanel1.ResumeLayout(false);
            OptinPanelWhitePanel1.PerformLayout();
            OptionPanelHeader1.ResumeLayout(false);
            OptionPanelBase2.ResumeLayout(false);
            OptionPanelMask2.ResumeLayout(false);
            white2.ResumeLayout(false);
            white2.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            OptionPanelBase3.ResumeLayout(false);
            OptionPanelMask3.ResumeLayout(false);
            white3.ResumeLayout(false);
            white3.PerformLayout();
            guna2Panel4.ResumeLayout(false);
            OptionPanelBase5.ResumeLayout(false);
            OptionPanelMask5.ResumeLayout(false);
            white5.ResumeLayout(false);
            white5.PerformLayout();
            guna2Panel6.ResumeLayout(false);
            OptionPanelBase4.ResumeLayout(false);
            OptionPanelMask4.ResumeLayout(false);
            white4.ResumeLayout(false);
            white4.PerformLayout();
            guna2Panel8.ResumeLayout(false);
            OptionPanelBase6.ResumeLayout(false);
            OptionPanelMask6.ResumeLayout(false);
            white6.ResumeLayout(false);
            white6.PerformLayout();
            guna2Panel10.ResumeLayout(false);
            MainPanel.ResumeLayout(false);
            MainPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Label OptionPanelDescription2;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Controls.OptionPanel OptionPanelBase1;
        private Controls.OptionPanel OptionPanelMask1;
        private Controls.HoverButton OptionPanelButton1;
        private Guna.UI2.WinForms.Guna2Panel OptinPanelWhitePanel1;
        private Label OptionPanelTraking1;
        private Label OptionPanelLiability1;
        private Label OptionPanelSizeDescription1;
        private Label OptionPanelName1;
        private Guna.UI2.WinForms.Guna2Panel OptionPanelHeader1;
        private Label OptionPanelPrice1;
        private Controls.OptionPanel OptionPanelBase2;
        private Controls.OptionPanel OptionPanelMask2;
        private Controls.HoverButton hoverButton1;
        private Guna.UI2.WinForms.Guna2Panel white2;
        private Label OptionPanelTraking2;
        private Label OptionPanelLiability2;
        private Label OptionPanelSizeDescription2;
        private Label OptionPanelName2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Label OptionPanelPrice2;
        private Controls.OptionPanel OptionPanelBase3;
        private Controls.OptionPanel OptionPanelMask3;
        private Controls.HoverButton OptionPanelButton3;
        private Guna.UI2.WinForms.Guna2Panel white3;
        private Label OptionPanelTraking3;
        private Label OptionPanelLiability3;
        private Label OptionPanelSizeDescription3;
        private Label OptionPanelName3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Label label10OptionPanelPrice3;
        private Controls.OptionPanel OptionPanelBase5;
        private Controls.OptionPanel OptionPanelMask5;
        private Controls.HoverButton OptionPanelButton5;
        private Guna.UI2.WinForms.Guna2Panel white5;
        private Label OptionPanelTraking5;
        private Label OptionPanelLiability5;
        private Label OptionPanelSizeDescription5;
        private Label OptionPanelName5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Label OptionPanelPrice5;
        private Controls.OptionPanel OptionPanelBase4;
        private Controls.OptionPanel OptionPanelMask4;
        private Controls.HoverButton OptionPanelButton4;
        private Guna.UI2.WinForms.Guna2Panel white4;
        private Label OptionPanelTraking4;
        private Label OptionPanelLiability4;
        private Label OptionPanelSizeDescription4;
        private Label OptionPanelName4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Label OptionPanelPrice4;
        private Guna.UI2.WinForms.Guna2Button btnNextPage;
        private Controls.OptionPanel OptionPanelBase6;
        private Controls.OptionPanel OptionPanelMask6;
        private Controls.HoverButton OptionPanelButton6;
        private Guna.UI2.WinForms.Guna2Panel white6;
        private Label OptionPanelTraking6;
        private Label OptionPanelLiability6;
        private Label OptionPanelSizeDescription6;
        private Label OptionPanelName6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Label OptionPanelPrice6;
        private Panel panel_login;
        private Label label1;
        private Panel MainPanel;
    }
}