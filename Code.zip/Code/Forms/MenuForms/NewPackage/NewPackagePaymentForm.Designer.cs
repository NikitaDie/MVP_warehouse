﻿namespace Forms.MenuForms.NewPackage
{
    partial class NewPackagePaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2CustomRadioButton1 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            white2 = new Guna.UI2.WinForms.Guna2Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            panel5 = new Panel();
            changeSenderButton = new Guna.UI2.WinForms.Guna2CircleButton();
            senderCountry = new Label();
            senderLocation = new Label();
            senderName = new Label();
            senderStreet = new Label();
            label11 = new Label();
            panel4 = new Panel();
            changeReceiverButton = new Guna.UI2.WinForms.Guna2CircleButton();
            receiverCountry = new Label();
            receiverLocation = new Label();
            receiverStreet = new Label();
            receiverName = new Label();
            Receiver = new Label();
            panel2 = new Panel();
            changePackageButton = new Guna.UI2.WinForms.Guna2CircleButton();
            panel6 = new Panel();
            packagePrice = new Label();
            label4 = new Label();
            packageName = new Label();
            label6 = new Label();
            packageDescription = new Label();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            label1 = new Label();
            guna2CustomRadioButton2 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            btnPay = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            label2 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            white2.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            guna2Panel2.SuspendLayout();
            guna2Panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2CustomRadioButton1
            // 
            guna2CustomRadioButton1.BackColor = Color.Transparent;
            guna2CustomRadioButton1.CheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            guna2CustomRadioButton1.CheckedState.BorderThickness = 1;
            guna2CustomRadioButton1.CheckedState.FillColor = Color.Transparent;
            guna2CustomRadioButton1.CheckedState.InnerColor = Color.FromArgb(212, 5, 17);
            guna2CustomRadioButton1.Location = new Point(11, 21);
            guna2CustomRadioButton1.Name = "guna2CustomRadioButton1";
            guna2CustomRadioButton1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2CustomRadioButton1.Size = new Size(24, 24);
            guna2CustomRadioButton1.TabIndex = 0;
            guna2CustomRadioButton1.Text = "guna2CustomRadioButton1";
            guna2CustomRadioButton1.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            guna2CustomRadioButton1.UncheckedState.BorderThickness = 1;
            guna2CustomRadioButton1.UncheckedState.FillColor = Color.Transparent;
            guna2CustomRadioButton1.UncheckedState.InnerColor = Color.Transparent;
            guna2CustomRadioButton1.UseTransparentBackground = true;
            // 
            // white2
            // 
            white2.BackColor = Color.Transparent;
            white2.BorderColor = Color.White;
            white2.BorderRadius = 9;
            white2.BorderThickness = 1;
            white2.Controls.Add(tableLayoutPanel2);
            white2.CustomizableEdges = customizableEdges15;
            white2.FillColor = SystemColors.Control;
            white2.Location = new Point(22, 25);
            white2.Name = "white2";
            white2.ShadowDecoration.BorderRadius = 8;
            white2.ShadowDecoration.CustomizableEdges = customizableEdges16;
            white2.ShadowDecoration.Depth = 15;
            white2.ShadowDecoration.Enabled = true;
            white2.Size = new Size(953, 138);
            white2.TabIndex = 10;
            white2.UseTransparentBackground = true;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel2.Controls.Add(panel5, 2, 0);
            tableLayoutPanel2.Controls.Add(panel4, 1, 0);
            tableLayoutPanel2.Controls.Add(panel2, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Size = new Size(953, 138);
            tableLayoutPanel2.TabIndex = 16;
            // 
            // panel5
            // 
            panel5.Controls.Add(changeSenderButton);
            panel5.Controls.Add(senderCountry);
            panel5.Controls.Add(senderLocation);
            panel5.Controls.Add(senderName);
            panel5.Controls.Add(senderStreet);
            panel5.Controls.Add(label11);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(669, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(281, 132);
            panel5.TabIndex = 18;
            // 
            // changeSenderButton
            // 
            changeSenderButton.CheckedState.FillColor = Color.Lime;
            changeSenderButton.DisabledState.BorderColor = Color.DarkGray;
            changeSenderButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changeSenderButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changeSenderButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changeSenderButton.FillColor = Color.FromArgb(210, 210, 210);
            changeSenderButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            changeSenderButton.ForeColor = Color.White;
            changeSenderButton.HoverState.FillColor = Color.FromArgb(212, 5, 17);
            changeSenderButton.HoverState.Image = Properties.Resources.clipart_pen_pen_icon_3_1gray__Traced_;
            changeSenderButton.Image = Properties.Resources.clipart_pen_pen_icon_3_1__Traced_;
            changeSenderButton.Location = new Point(214, 8);
            changeSenderButton.Name = "changeSenderButton";
            changeSenderButton.PressedColor = Color.Transparent;
            changeSenderButton.PressedDepth = 0;
            changeSenderButton.ShadowDecoration.CustomizableEdges = customizableEdges17;
            changeSenderButton.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            changeSenderButton.Size = new Size(40, 40);
            changeSenderButton.TabIndex = 18;
            // 
            // senderCountry
            // 
            senderCountry.AutoSize = true;
            senderCountry.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            senderCountry.ForeColor = Color.FromArgb(90, 90, 90);
            senderCountry.Location = new Point(7, 100);
            senderCountry.Name = "senderCountry";
            senderCountry.Size = new Size(146, 20);
            senderCountry.TabIndex = 14;
            senderCountry.Text = "max. 30 x 25 x 10 cm";
            // 
            // senderLocation
            // 
            senderLocation.AutoSize = true;
            senderLocation.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            senderLocation.ForeColor = Color.FromArgb(90, 90, 90);
            senderLocation.Location = new Point(7, 80);
            senderLocation.Name = "senderLocation";
            senderLocation.Size = new Size(146, 20);
            senderLocation.TabIndex = 13;
            senderLocation.Text = "max. 30 x 25 x 10 cm";
            // 
            // senderName
            // 
            senderName.AutoSize = true;
            senderName.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            senderName.ForeColor = Color.FromArgb(90, 90, 90);
            senderName.Location = new Point(7, 40);
            senderName.Name = "senderName";
            senderName.Size = new Size(146, 20);
            senderName.TabIndex = 12;
            senderName.Text = "max. 30 x 25 x 10 cm";
            // 
            // senderStreet
            // 
            senderStreet.AutoSize = true;
            senderStreet.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            senderStreet.ForeColor = Color.FromArgb(90, 90, 90);
            senderStreet.Location = new Point(7, 60);
            senderStreet.Name = "senderStreet";
            senderStreet.Size = new Size(146, 20);
            senderStreet.TabIndex = 11;
            senderStreet.Text = "max. 30 x 25 x 10 cm";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Leelawadee UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(50, 50, 50);
            label11.Location = new Point(3, 12);
            label11.Name = "label11";
            label11.Size = new Size(75, 25);
            label11.TabIndex = 10;
            label11.Text = "Sender";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.Controls.Add(changeReceiverButton);
            panel4.Controls.Add(receiverCountry);
            panel4.Controls.Add(receiverLocation);
            panel4.Controls.Add(receiverStreet);
            panel4.Controls.Add(receiverName);
            panel4.Controls.Add(Receiver);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(384, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(279, 132);
            panel4.TabIndex = 18;
            // 
            // changeReceiverButton
            // 
            changeReceiverButton.CheckedState.FillColor = Color.Lime;
            changeReceiverButton.DisabledState.BorderColor = Color.DarkGray;
            changeReceiverButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changeReceiverButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changeReceiverButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changeReceiverButton.FillColor = Color.FromArgb(210, 210, 210);
            changeReceiverButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            changeReceiverButton.ForeColor = Color.White;
            changeReceiverButton.HoverState.FillColor = Color.FromArgb(212, 5, 17);
            changeReceiverButton.HoverState.Image = Properties.Resources.clipart_pen_pen_icon_3_1gray__Traced_;
            changeReceiverButton.Image = Properties.Resources.clipart_pen_pen_icon_3_1__Traced_;
            changeReceiverButton.Location = new Point(214, 8);
            changeReceiverButton.Name = "changeReceiverButton";
            changeReceiverButton.PressedColor = Color.Transparent;
            changeReceiverButton.PressedDepth = 0;
            changeReceiverButton.ShadowDecoration.CustomizableEdges = customizableEdges18;
            changeReceiverButton.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            changeReceiverButton.Size = new Size(40, 40);
            changeReceiverButton.TabIndex = 18;
            // 
            // receiverCountry
            // 
            receiverCountry.AutoSize = true;
            receiverCountry.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            receiverCountry.ForeColor = Color.FromArgb(90, 90, 90);
            receiverCountry.Location = new Point(7, 100);
            receiverCountry.Name = "receiverCountry";
            receiverCountry.Size = new Size(146, 20);
            receiverCountry.TabIndex = 12;
            receiverCountry.Text = "max. 30 x 25 x 10 cm";
            // 
            // receiverLocation
            // 
            receiverLocation.AutoSize = true;
            receiverLocation.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            receiverLocation.ForeColor = Color.FromArgb(90, 90, 90);
            receiverLocation.Location = new Point(7, 80);
            receiverLocation.Name = "receiverLocation";
            receiverLocation.Size = new Size(146, 20);
            receiverLocation.TabIndex = 11;
            receiverLocation.Text = "max. 30 x 25 x 10 cm";
            // 
            // receiverStreet
            // 
            receiverStreet.AutoSize = true;
            receiverStreet.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            receiverStreet.ForeColor = Color.FromArgb(90, 90, 90);
            receiverStreet.Location = new Point(7, 60);
            receiverStreet.Name = "receiverStreet";
            receiverStreet.Size = new Size(146, 20);
            receiverStreet.TabIndex = 10;
            receiverStreet.Text = "max. 30 x 25 x 10 cm";
            // 
            // receiverName
            // 
            receiverName.AutoSize = true;
            receiverName.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            receiverName.ForeColor = Color.FromArgb(90, 90, 90);
            receiverName.Location = new Point(7, 40);
            receiverName.Name = "receiverName";
            receiverName.Size = new Size(146, 20);
            receiverName.TabIndex = 9;
            receiverName.Text = "max. 30 x 25 x 10 cm";
            receiverName.Click += receiverName_Click;
            // 
            // Receiver
            // 
            Receiver.AutoSize = true;
            Receiver.BackColor = Color.Transparent;
            Receiver.Font = new Font("Leelawadee UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            Receiver.ForeColor = Color.FromArgb(50, 50, 50);
            Receiver.Location = new Point(3, 13);
            Receiver.Name = "Receiver";
            Receiver.Size = new Size(86, 25);
            Receiver.TabIndex = 8;
            Receiver.Text = "Receiver";
            Receiver.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.Controls.Add(changePackageButton);
            panel2.Controls.Add(panel6);
            panel2.Controls.Add(packagePrice);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(packageName);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(packageDescription);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(375, 132);
            panel2.TabIndex = 18;
            // 
            // changePackageButton
            // 
            changePackageButton.CheckedState.FillColor = Color.Lime;
            changePackageButton.DisabledState.BorderColor = Color.DarkGray;
            changePackageButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changePackageButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changePackageButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changePackageButton.FillColor = Color.FromArgb(210, 210, 210);
            changePackageButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            changePackageButton.ForeColor = Color.White;
            changePackageButton.HoverState.FillColor = Color.FromArgb(212, 5, 17);
            changePackageButton.HoverState.Image = Properties.Resources.clipart_pen_pen_icon_3_1gray__Traced_;
            changePackageButton.Image = Properties.Resources.clipart_pen_pen_icon_3_1__Traced_;
            changePackageButton.Location = new Point(308, 8);
            changePackageButton.Name = "changePackageButton";
            changePackageButton.PressedColor = Color.Transparent;
            changePackageButton.PressedDepth = 0;
            changePackageButton.ShadowDecoration.CustomizableEdges = customizableEdges19;
            changePackageButton.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            changePackageButton.Size = new Size(40, 40);
            changePackageButton.TabIndex = 17;
            // 
            // panel6
            // 
            panel6.BackColor = SystemColors.ScrollBar;
            panel6.Location = new Point(368, 13);
            panel6.Name = "panel6";
            panel6.Size = new Size(1, 107);
            panel6.TabIndex = 23;
            // 
            // packagePrice
            // 
            packagePrice.BackColor = Color.Transparent;
            packagePrice.Font = new Font("Leelawadee UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            packagePrice.ForeColor = Color.FromArgb(50, 50, 50);
            packagePrice.Location = new Point(276, 91);
            packagePrice.Name = "packagePrice";
            packagePrice.Size = new Size(93, 32);
            packagePrice.TabIndex = 11;
            packagePrice.Text = "3,99 €";
            packagePrice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(90, 90, 90);
            label4.Image = Properties.Resources.rotCross1;
            label4.ImageAlign = ContentAlignment.MiddleLeft;
            label4.Location = new Point(19, 83);
            label4.Name = "label4";
            label4.Size = new Size(145, 20);
            label4.TabIndex = 10;
            label4.Text = "    Shipment tracking";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // packageName
            // 
            packageName.BackColor = Color.Transparent;
            packageName.Font = new Font("Leelawadee UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            packageName.ForeColor = Color.FromArgb(50, 50, 50);
            packageName.Location = new Point(13, 8);
            packageName.Name = "packageName";
            packageName.Size = new Size(160, 32);
            packageName.TabIndex = 7;
            packageName.Text = "2 kg - Package S";
            packageName.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(90, 90, 90);
            label6.Image = Properties.Resources.rotCross1;
            label6.ImageAlign = ContentAlignment.MiddleLeft;
            label6.Location = new Point(19, 63);
            label6.Name = "label6";
            label6.Size = new Size(77, 20);
            label6.TabIndex = 9;
            label6.Text = "    Liability";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // packageDescription
            // 
            packageDescription.AutoSize = true;
            packageDescription.Font = new Font("Leelawadee UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            packageDescription.ForeColor = Color.FromArgb(90, 90, 90);
            packageDescription.Location = new Point(30, 40);
            packageDescription.Name = "packageDescription";
            packageDescription.Size = new Size(146, 20);
            packageDescription.TabIndex = 8;
            packageDescription.Text = "max. 30 x 25 x 10 cm";
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.Transparent;
            guna2Panel2.BorderColor = SystemColors.Control;
            guna2Panel2.BorderRadius = 9;
            guna2Panel2.BorderThickness = 1;
            guna2Panel2.Controls.Add(label1);
            guna2Panel2.Controls.Add(guna2CustomRadioButton2);
            guna2Panel2.CustomizableEdges = customizableEdges21;
            guna2Panel2.FillColor = SystemColors.Control;
            guna2Panel2.Location = new Point(3, 3);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.BorderRadius = 8;
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2Panel2.ShadowDecoration.Depth = 20;
            guna2Panel2.ShadowDecoration.Enabled = true;
            guna2Panel2.Size = new Size(339, 63);
            guna2Panel2.TabIndex = 12;
            guna2Panel2.UseTransparentBackground = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(50, 50, 50);
            label1.Location = new Point(41, 21);
            label1.Name = "label1";
            label1.Size = new Size(93, 21);
            label1.TabIndex = 8;
            label1.Text = "Credit card";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // guna2CustomRadioButton2
            // 
            guna2CustomRadioButton2.BackColor = Color.Transparent;
            guna2CustomRadioButton2.Checked = true;
            guna2CustomRadioButton2.CheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            guna2CustomRadioButton2.CheckedState.BorderThickness = 1;
            guna2CustomRadioButton2.CheckedState.FillColor = Color.Transparent;
            guna2CustomRadioButton2.CheckedState.InnerColor = Color.FromArgb(212, 5, 17);
            guna2CustomRadioButton2.Location = new Point(11, 21);
            guna2CustomRadioButton2.Name = "guna2CustomRadioButton2";
            guna2CustomRadioButton2.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2CustomRadioButton2.Size = new Size(24, 24);
            guna2CustomRadioButton2.TabIndex = 1;
            guna2CustomRadioButton2.Text = "guna2CustomRadioButton2";
            guna2CustomRadioButton2.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            guna2CustomRadioButton2.UncheckedState.BorderThickness = 1;
            guna2CustomRadioButton2.UncheckedState.FillColor = Color.Transparent;
            guna2CustomRadioButton2.UncheckedState.InnerColor = Color.Transparent;
            guna2CustomRadioButton2.UseTransparentBackground = true;
            // 
            // btnPay
            // 
            btnPay.Animated = true;
            btnPay.BorderColor = Color.Transparent;
            btnPay.BorderRadius = 3;
            btnPay.BorderThickness = 2;
            btnPay.CheckedState.BorderColor = Color.FromArgb(212, 5, 17);
            btnPay.CheckedState.FillColor = SystemColors.Control;
            btnPay.CheckedState.ForeColor = Color.FromArgb(212, 5, 17);
            btnPay.CustomizableEdges = customizableEdges23;
            btnPay.DisabledState.BorderColor = Color.DarkGray;
            btnPay.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPay.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPay.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPay.FillColor = Color.FromArgb(212, 5, 17);
            btnPay.Font = new Font("Calibri", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnPay.ForeColor = Color.White;
            btnPay.HoverState.BorderColor = Color.FromArgb(212, 5, 17);
            btnPay.HoverState.FillColor = Color.Transparent;
            btnPay.HoverState.ForeColor = Color.FromArgb(212, 5, 17);
            btnPay.Location = new Point(19, 542);
            btnPay.Name = "btnPay";
            btnPay.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnPay.Size = new Size(345, 39);
            btnPay.TabIndex = 13;
            btnPay.Text = "Pay";
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = Color.Transparent;
            guna2Panel1.BorderColor = SystemColors.Control;
            guna2Panel1.BorderRadius = 9;
            guna2Panel1.BorderThickness = 1;
            guna2Panel1.Controls.Add(label2);
            guna2Panel1.Controls.Add(guna2CustomRadioButton1);
            guna2Panel1.CustomizableEdges = customizableEdges25;
            guna2Panel1.FillColor = SystemColors.Control;
            guna2Panel1.Location = new Point(3, 79);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.BorderRadius = 8;
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2Panel1.ShadowDecoration.Depth = 15;
            guna2Panel1.ShadowDecoration.Enabled = true;
            guna2Panel1.Size = new Size(339, 63);
            guna2Panel1.TabIndex = 14;
            guna2Panel1.UseTransparentBackground = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Leelawadee UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(50, 50, 50);
            label2.Location = new Point(41, 21);
            label2.Name = "label2";
            label2.Size = new Size(46, 21);
            label2.TabIndex = 8;
            label2.Text = "Cash";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(guna2Panel2, 0, 0);
            tableLayoutPanel1.Controls.Add(guna2Panel1, 0, 1);
            tableLayoutPanel1.Location = new Point(19, 383);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(345, 153);
            tableLayoutPanel1.TabIndex = 15;
            // 
            // NewPackagePaymentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(1000, 600);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(btnPay);
            Controls.Add(white2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewPackagePaymentForm";
            Text = "NewPackagePaymentForm";
            white2.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomRadioButton guna2CustomRadioButton1;
        private Guna.UI2.WinForms.Guna2Panel white2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Button btnPay;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2CustomRadioButton guna2CustomRadioButton2;
        private Label label1;
        private Label label2;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private Panel panel2;
        private Label packagePrice;
        private Label label4;
        private Label packageName;
        private Label label6;
        private Label packageDescription;
        private Panel panel4;
        private Label Receiver;
        private Panel panel5;
        private Label label11;
        private Panel panel6;
        private Label receiverName;
        private Label senderCountry;
        private Label senderLocation;
        private Label senderName;
        private Label senderStreet;
        private Label receiverCountry;
        private Label receiverLocation;
        private Label receiverStreet;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2CircleButton changePackageButton;
        private Guna.UI2.WinForms.Guna2CircleButton changeSenderButton;
        private Guna.UI2.WinForms.Guna2CircleButton changeReceiverButton;
    }
}